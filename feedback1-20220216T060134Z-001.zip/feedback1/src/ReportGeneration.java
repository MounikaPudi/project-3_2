import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.Chunk;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;

import dao.DBConnection;
import dao.Feedback;


public class ReportGeneration {

	PdfWriter writer;
	public void createPDF(Connection con,String type)
	{
		Document document = new Document( PageSize.A4,30,36,25,36 );
    	
          
		try {
			writer =PdfWriter.getInstance(document,new FileOutputStream("e:\\reports\\facultyPDF.pdf"));
	        document.open();
	        
	        
	        
			ResultSet rs=con.createStatement().executeQuery("select * from facultyfeedback");
			while(rs.next())
			{
				Feedback fb=new Feedback();
				fb.setAy(rs.getString(23));
				
				Date date = Calendar.getInstance().getTime();
                DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                String today = formatter.format(date);

                
				fb.setDate(today);
				
				fb.setCls(rs.getString(1));
				fb.setBranch(rs.getString(3));
				fb.setStaff(rs.getString(25));
				fb.setDept(rs.getString(24));
				fb.setSname(rs.getString(2));
				
				fb.setA1(rs.getString(4));
				fb.setA2(rs.getString(5));
				fb.setA3(rs.getString(6));
				
				fb.setB1(rs.getString(7));
				fb.setB2(rs.getString(8));
				fb.setB3(rs.getString(9));
				fb.setB4(rs.getString(10));
				
				fb.setC1(rs.getString(11));
				fb.setC2(rs.getString(12));
				fb.setC3(rs.getString(13));
				
				fb.setD1(rs.getString(14));
				fb.setD2(rs.getString(15));
				fb.setD3(rs.getString(16));
				
				fb.setA(rs.getString(17));
				fb.setB(rs.getString(18));
				fb.setC(rs.getString(19));
				fb.setD(rs.getString(20));
				
				fb.setResult(rs.getString(21));
				fb.setTotst(rs.getString(22));
				
				if(type.equals("general"))
					showContents(document,fb,"general");
				else if(type.equals("fe"))
					showContents(document,fb,"fe");
				else if(type.equals("oe"))
					showContents(document,fb,"oe");
				
	            document.newPage();
				
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

    	document.close();
    
	}
		
	public void showContents(Document document, Feedback fb,String type)
	{
		
		try {
            


         String imageUrl = "f:\\reports\\logo.jpg";

         Image image = Image.getInstance(imageUrl);
         image.setAbsolutePosition(32f,700f);
         document.add(image);

         BaseFont bf1 = BaseFont.createFont(BaseFont.TIMES_ROMAN, BaseFont.CP1250, BaseFont.NOT_EMBEDDED);
         Paragraph t1=new Paragraph("SHRI VISHNU ENGINEERING COLLEGE FOR WOMEN",new Font(bf1,16,Font.BOLD));
         t1.setAlignment(Element.ALIGN_CENTER);

         Paragraph t2=new Paragraph("Vishnupur, BHIMAVARAM - 534202",new Font(bf1,14,Font.BOLD));
         t2.setAlignment(Element.ALIGN_CENTER);

         Paragraph t3=new Paragraph("APPROVED BY AICTE & AFFILIATED TO JNTUK",new Font(bf1,10));
         t3.setAlignment(Element.ALIGN_CENTER);

         Paragraph t4=new Paragraph("(SRI VISHNU EDUCATIONAL SOCIETY)",new Font(bf1,10));
         t4.setAlignment(Element.ALIGN_CENTER);

         Paragraph t5=new Paragraph("FEEDBACK ON FACULTY BY STUDENTS",new Font(bf1,13,Font.BOLD));
         t5.setAlignment(Element.ALIGN_CENTER);



         document.add( t1);
         document.add( t2);
         document.add( t3);
         document.add( t4);
         document.add( Chunk.NEWLINE );

         document.add( t5);


         placeChunck("ACADEMIC YEAR:",40,670,12);
         placeChunck(fb.getAy(),150,670,12);
         placeChunck("CLASS:",40,640,12);
         placeChunck(fb.getCls(),85,640,12);
         placeChunck("STAFF MEMBER:",40,610,12);
         placeChunck(fb.getStaff(),145,610,12);
         placeChunck("DEPARTMENT:",40,580,12);
         placeChunck(fb.getDept(),135,580,12);
         placeChunck("SUBJECT NAME:",40,550,12);
         String subname=fb.getSname();
         if(subname.length()>50)
        	 placeChunck(subname,140,550,9);
         else
        	 placeChunck(subname,140,550,12);
         placeChunck("DATE:",380,670,12);
         placeChunck(fb.getDate(),420,670,12);
         
         if(type.equals("general"))
         {
        	 placeChunck("SECTION:",380,640,12);
             placeChunck(fb.getBranch(),440,640,12);
             	 
         }
         
         BaseFont bf = BaseFont.createFont(BaseFont.TIMES_ROMAN, BaseFont.CP1250, BaseFont.NOT_EMBEDDED);
         document.add( Chunk.NEWLINE );
         document.add( Chunk.NEWLINE );
         document.add( Chunk.NEWLINE );
         document.add( Chunk.NEWLINE );
         document.add( Chunk.NEWLINE );
         document.add( Chunk.NEWLINE );
         document.add( Chunk.NEWLINE );
         document.add( Chunk.NEWLINE );
         
     PdfPTable table = new PdfPTable(3); // Code 1



     table.setWidthPercentage(90);
     table.setWidths(new int[]{5,80,10});

     PdfPCell aRow=new PdfPCell(new Phrase("A. PLANNING & ORGANIZATION",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
     aRow.setHorizontalAlignment(Element.ALIGN_CENTER);
     aRow.setVerticalAlignment(Element.ALIGN_CENTER);
     aRow.setColspan(3);
     aRow.setFixedHeight(19f);
     table.addCell(aRow);

     PdfPCell nocell;


          // Code 2
             nocell=new PdfPCell(new Phrase("1.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Planning and Arranging the Subjects",new Font(bf,13)));

             table.addCell(new Phrase(fb.getA1(),new Font(bf,13)));

             nocell=new PdfPCell(new Phrase("2.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
             table.addCell(nocell);

             table.addCell(new Phrase("Coverage of all topics till today",new Font(bf,13)));
             table.addCell(new Phrase(fb.getA2(),new Font(bf,13)));


             nocell=new PdfPCell(new Phrase("3.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Effective use of time",new Font(bf,13)));
             table.addCell(new Phrase(fb.getA3(),new Font(bf,13)));

             PdfPCell bRow=new PdfPCell(new Phrase("B. PRESENTATION / COMMUNICATION",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             bRow.setHorizontalAlignment(Element.ALIGN_CENTER);
             bRow.setColspan(3);
             bRow.setFixedHeight(19f);
             table.addCell(bRow);

             nocell=new PdfPCell(new Phrase("1.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);


             table.addCell(new Phrase("Communication Ability and clarity of expression",new Font(bf,13)));
             table.addCell(new Phrase(fb.getB1(),new Font(bf,13)));


             nocell=new PdfPCell(new Phrase("2.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);


             table.addCell(new Phrase("Presentation of concepts and Principles",new Font(bf,13)));
             table.addCell(new Phrase(fb.getB2(),new Font(bf,13)));


             nocell=new PdfPCell(new Phrase("3.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Effective use of Diagrams / Sketches",new Font(bf,13)));
             table.addCell(new Phrase(fb.getB3(),new Font(bf,13)));


             nocell=new PdfPCell(new Phrase("4.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Providing useful tutorials /  assignments",new Font(bf,13)));
             table.addCell(new Phrase(fb.getB4(),new Font(bf,13)));


             PdfPCell cRow=new PdfPCell(new Phrase("C. CLASS MANAGEMENT",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             cRow.setHorizontalAlignment(Element.ALIGN_CENTER);
             cRow.setColspan(3);
             cRow.setFixedHeight(19f);
             table.addCell(cRow);

             nocell=new PdfPCell(new Phrase("1.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Engaging classes regularly and panctually",new Font(bf,13)));
             table.addCell(new Phrase(fb.getC1(),new Font(bf,13)));


             nocell=new PdfPCell(new Phrase("2.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Encouragement to raise doubts / questions",new Font(bf,13)));
             table.addCell(new Phrase(fb.getC2(),new Font(bf,13)));


             nocell=new PdfPCell(new Phrase("3.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Ensuring student attention / interest",new Font(bf,13)));
             table.addCell(new Phrase(fb.getC3(),new Font(bf,13)));

             PdfPCell dRow=new PdfPCell(new Phrase("D. MEDIA / METHODS",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             dRow.setHorizontalAlignment(Element.ALIGN_CENTER);
             dRow.setColspan(3);
             dRow.setFixedHeight(19f);
             table.addCell(dRow);

             nocell=new PdfPCell(new Phrase("1.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Using a variety of teaching techniques",new Font(bf,13)));
             table.addCell(new Phrase(fb.getD1(),new Font(bf,13)));


             nocell=new PdfPCell(new Phrase("2.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Clean and systematic chalk board work",new Font(bf,13)));
             table.addCell(new Phrase(fb.getD2(),new Font(bf,13)));


             nocell=new PdfPCell(new Phrase("3.",new Font(bf,13)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		table.addCell(nocell);

             table.addCell(new Phrase("Encouraging use of library",new Font(bf,13)));
             table.addCell(new Phrase(fb.getD3(),new Font(bf,13)));


             PdfPTable restable = new PdfPTable(3); // Code 1
             restable.setWidthPercentage(90);
             restable.setWidths(new int[]{5,80,10});

             PdfPCell resRow=new PdfPCell(new Phrase("RESULTS",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             resRow.setHorizontalAlignment(Element.ALIGN_CENTER);
             resRow.setColspan(3);
             resRow.setFixedHeight(19f);
             restable.addCell(resRow);

             nocell=new PdfPCell(new Phrase("A.",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		restable.addCell(nocell);

             restable.addCell(new Phrase("PLANNING & ORGANIZATION",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             restable.addCell(new Phrase(fb.getA(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));


             nocell=new PdfPCell(new Phrase("B.",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
		restable.addCell(nocell);

             restable.addCell(new Phrase("PRESENTATION / COMMUNICATION",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             restable.addCell(new Phrase(fb.getB(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));


             nocell=new PdfPCell(new Phrase("C.",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setFixedHeight(19f);
             nocell.setVerticalAlignment(Element.ALIGN_CENTER);
             restable.addCell(nocell);
             
             //addingCell(new Phrase("CLASS MANAGEMENT",new Font(bf,13)),restable);
		restable.addCell(new Phrase("CLASS MANAGEMENT",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             restable.addCell(new Phrase(fb.getC(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));


             nocell=new PdfPCell(new Phrase("D.",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
		restable.addCell(nocell);

             restable.addCell(new Phrase("MEDIA / METHODS",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             restable.addCell(new Phrase(fb.getD(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));

             nocell=new PdfPCell(new Phrase("TOTAL RESPONSE FROM STUDENTS",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setColspan(2);
		restable.addCell(nocell);
             restable.addCell(new Phrase(fb.getResult(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));


             nocell=new PdfPCell(new Phrase("TOTAL NO.OF STUDENTS ATTEMPTED",FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));
             nocell.setHorizontalAlignment(Element.ALIGN_CENTER);
             nocell.setColspan(2);
		restable.addCell(nocell);
             restable.addCell(new Phrase(fb.getTotst(),FontFactory.getFont(FontFactory.TIMES_ROMAN, 12, Font.BOLD,null)));



             Paragraph p5=new Paragraph();
		p5.setFont(new Font(bf));
		p5.add(table);
		document.add(p5);

             document.add( Chunk.NEWLINE );
             

             Paragraph p6=new Paragraph();
		p6.setFont(new Font(bf));
		p6.add(restable);
		document.add(p6);



		


     } catch(Exception e){
         e.printStackTrace();
     }
 }

 
     private   void placeChunck(String text, int x, int y) {
     	try {
         PdfContentByte cb = writer.getDirectContent();
         BaseFont bf = BaseFont.createFont(BaseFont.TIMES_BOLD, BaseFont.CP1250, BaseFont.NOT_EMBEDDED);
         cb.saveState();
         cb.beginText();
         cb.moveText(x, y);
         cb.setFontAndSize(bf, 12);

         cb.showText(text);
         cb.endText();
         cb.restoreState();


     	} catch (DocumentException e) {
     		e.printStackTrace();     }
     	catch (IOException e) {       e.printStackTrace();     }
         }
     private   void placeChunck(String text, int x, int y,int size) {
     	try {
         PdfContentByte cb = writer.getDirectContent();
         BaseFont bf = BaseFont.createFont(BaseFont.TIMES_BOLD, BaseFont.CP1250, BaseFont.NOT_EMBEDDED);
         cb.saveState();
         cb.beginText();
         cb.moveText(x, y);
         cb.setFontAndSize(bf, size);
         
         cb.showText(text);
         cb.endText();
         cb.restoreState();


     	} catch (DocumentException e) {
     		e.printStackTrace();     }
     	catch (IOException e) {       e.printStackTrace();     }
         }

	public void createFEPDF(Connection con) {
		// TODO Auto-generated method stub
		
	}

/*public static void main(String ar[])
{
ReportGeneration rg=new ReportGeneration();
rg.createPDF(new DBConnection().getDatabaseConnection());
}*/


}
