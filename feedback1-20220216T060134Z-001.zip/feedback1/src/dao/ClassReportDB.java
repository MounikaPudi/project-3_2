package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ClassReportDB {
	java.sql.Connection con;
	Statement st;
	ResultSet rs;
	FBSMiscUtilitiesBean utilities=new FBSMiscUtilitiesBean();
	FBSFetchDataBean databean=new FBSFetchDataBean();
	
	
	public ClassReportDB()
	{
		//con=new DBConnection().getDatabaseConnection();
	}
	
	public void loadData(String branch1,String year1,String sem1,String sec,String type)
	{
	
		try {
			con=new DBConnection().getDatabaseConnection();
			con.createStatement().executeUpdate("delete from facultyfeedback");
			
			String query="SELECT f.mapid,ceil(sum(a1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b4)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(c1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c3)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d3)/(cast((count(f.sno)*5) as decimal))*100),count(f.sno) from feedback f where  f.mapid in (select mapid from mapsubjects where sid in(select sid from subjects where branch=? and year=? and sem=?) and section=?)  group by f.mapid";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, branch1);
			ps.setString(2, year1);
			ps.setString(3, sem1);
			ps.setString(4, sec);
			//System.out.println(fname+dept);
			ResultSet rs=ps.executeQuery();
			String insertQuery=new String();
			while(rs.next())
			{
				String mapid=rs.getString(1);
				int a1=rs.getInt(2);
				int a2=rs.getInt(3);
				int a3=rs.getInt(4);
				int b1=rs.getInt(5);
				int b2=rs.getInt(6);
				int b3=rs.getInt(7);
				int b4=rs.getInt(8);
				int c1=rs.getInt(9);
				int c2=rs.getInt(10);
				int c3=rs.getInt(11);
				int d1=rs.getInt(12);
				int d2=rs.getInt(13);
				int d3=rs.getInt(14);
				int a=(int)(Math.ceil((a1+a2+a3)/3));
				int b=(int)(Math.ceil((b1+b2+b3+b4)/4));
				int c=(int)(Math.ceil((c1+c2+c3)/3));
				int d=(int)(Math.ceil((d1+d2+d3)/3));
				int totres=(int)(Math.ceil((a+b+c+d)/4));
				int totst=rs.getInt(15);
				String subquery="select section,s.subname,s.branch,s.year,s.sem,s.ay from mapsubjects m,subjects s where mapid=? and m.sid=s.sid";
				PreparedStatement pq=con.prepareStatement(subquery);
				pq.setString(1,mapid);
				
				ResultSet sub=pq.executeQuery();
				String subname=new String();
				String branch=new String();
				String year=new String();
				String sem=new String();
				String section=new String();
				String ay=new String();
				
				if(sub.next())
				{
					 subname=sub.getString(2);
					 branch=sub.getString(3);
					 year=sub.getString(4);
					 sem=sub.getString(5);
					 section=sub.getString(1);
					ay=sub.getString(6);
						
				}
				String fquery="select fname,dept from faculty where fid=(select fid from mapsubjects where mapid=?)";
				PreparedStatement fst=con.prepareStatement(fquery);
				fst.setString(1, mapid);
				ResultSet frs=fst.executeQuery();
				String fname=new String();
				String dept=new String();
				if(frs.next())
				{
					fname=frs.getString(1);
					dept=frs.getString(2);
				}
				
				String totqry="";
				System.out.println(branch1+" "+year1);
				if(!branch1.equals("M.B.A")&&year1.equals("I"))
					totqry="select count(*) from students where   syear=? and sem=? and section=?";
				else
					totqry="select count(*) from students where   syear=? and sem=? and section=? and branch=?";
				System.out.println(totqry);	
				PreparedStatement totp =con.prepareStatement(totqry);
				//totp.setString(1, branch);
				totp.setString(1, year1);
				totp.setString(2, sem1);
				totp.setString(3, sec);
				if(!(!branch1.equals("M.B.A")&&year1.equals("I")))
					totp.setString(4, branch1);
				ResultSet totr=totp.executeQuery();
				
				int sttotal=0;
				if(totr.next())
					sttotal=totr.getInt(1);
				String totop=totst+" / "+sttotal;
                 				
				//System.out.println(sttotal);
				String cls="";
				if(!branch1.equals("M.B.A"))
					cls=year+" B.TECH - "+sem+" SEM";
				else
					cls=year+" M.B.A - "+sem+" SEM";
				String brch=section;
				insertQuery="insert into facultyfeedback values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				
				PreparedStatement iq=con.prepareStatement(insertQuery);
				
				iq.setString(1, cls);
				iq.setString(2, subname);
				iq.setString(3, brch);
				iq.setInt(4, a1);
				iq.setInt(5, a2);
				iq.setInt(6, a3);
				iq.setInt(7, b1);
				iq.setInt(8, b2);
				iq.setInt(9, b3);
				iq.setInt(10, b4);
				iq.setInt(11, c1);
				iq.setInt(12, c2);
				iq.setInt(13, c3);
				iq.setInt(14, d1);
				iq.setInt(15, d2);
				iq.setInt(16, d3);
				iq.setInt(17, a);
				iq.setInt(18, b);
				iq.setInt(19, c);
				iq.setInt(20, d);
				iq.setInt(21, totres);
				iq.setString(22, totop);
				iq.setString(23, ay);
				if(type.equals("aggregate"))
					iq.setString(24, dept);
				else
				iq.setString(24, getDeptName(dept));
							
				iq.setString(25,fname);
				iq.executeUpdate();
				
			}
				/*String subname=rs.getString(1);
				String branch=rs.getString(2);
				String year=rs.getString(3);
				String sem=rs.getString(4);
				String section=rs.getString(5);
				int a1=rs.getInt(6);
				int a2=rs.getInt(7);
				int a3=rs.getInt(8);
				int b1=rs.getInt(9);
				int b2=rs.getInt(10);
				int b3=rs.getInt(11);
				int b4=rs.getInt(12);
				int c1=rs.getInt(13);
				int c2=rs.getInt(14);
				int c3=rs.getInt(15);
				int d1=rs.getInt(16);
				int d2=rs.getInt(17);
				int d3=rs.getInt(18);
				int a=(int)(Math.ceil((a1+a2+a3)/3));
				int b=(int)(Math.ceil((b1+b2+b3+b4)/4));
				int c=(int)(Math.ceil((c1+c2+c3)/3));
				int d=(int)(Math.ceil((d1+d2+d3)/3));
				int totres=(int)(Math.ceil((a+b+c+d)/4));
				int totst=rs.getInt(19);
				String ay=rs.getString(20);
				System.out.println(subname+branch+section);
				String cls=year+" B.TECH - "+sem+" SEM";
				String brch=branch+" - "+section;
				insertQuery="insert into facultyfeedback values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				
				PreparedStatement iq=con.prepareStatement(insertQuery);
				
				iq.setString(1, cls);
				iq.setString(2, subname);
				iq.setString(3, brch);
				iq.setInt(4, a1);
				iq.setInt(5, a2);
				iq.setInt(6, a3);
				iq.setInt(7, b1);
				iq.setInt(8, b2);
				iq.setInt(9, b3);
				iq.setInt(10, b4);
				iq.setInt(11, c1);
				iq.setInt(12, c2);
				iq.setInt(13, c3);
				iq.setInt(14, d1);
				iq.setInt(15, d2);
				iq.setInt(16, d3);
				iq.setInt(17, a);
				iq.setInt(18, b);
				iq.setInt(19, c);
				iq.setInt(20, d);
				iq.setInt(21, totres);
				iq.setInt(22, totst);
				iq.setString(23, ay);
				iq.setString(24, dept);
				iq.executeUpdate();*/
				
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		  new DBConnection().releaseDatabaseConnection(con);
		
	}
	public void loadFEData(String class1,String ay1)
	{
	
		try {
			con=new DBConnection().getDatabaseConnection();
			con.createStatement().executeUpdate("delete from facultyfeedback");
			
			String query="";
			if(class1.contains("M.B.A"))
				query="SELECT f.mapid,ceil(sum(a1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b4)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(c1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c3)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d3)/(cast((count(f.sno)*5) as decimal))*100),count(f.sno) from feedback f where  f.mapid in (select mapid from femap where sid like 'PGMB%')  group by f.mapid";
			else
				query="SELECT f.mapid,ceil(sum(a1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b4)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(c1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c3)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d3)/(cast((count(f.sno)*5) as decimal))*100),count(f.sno) from feedback f where  f.mapid in (select mapid from femap where sid not like 'PGMB%')  group by f.mapid";
			PreparedStatement ps=con.prepareStatement(query);
			
			//System.out.println(fname+dept);
			ResultSet rs=ps.executeQuery();
			String insertQuery=new String();
			while(rs.next())
			{
				String mapid=rs.getString(1);
				int a1=rs.getInt(2);
				int a2=rs.getInt(3);
				int a3=rs.getInt(4);
				int b1=rs.getInt(5);
				int b2=rs.getInt(6);
				int b3=rs.getInt(7);
				int b4=rs.getInt(8);
				int c1=rs.getInt(9);
				int c2=rs.getInt(10);
				int c3=rs.getInt(11);
				int d1=rs.getInt(12);
				int d2=rs.getInt(13);
				int d3=rs.getInt(14);
				int a=(int)(Math.ceil((a1+a2+a3)/3));
				int b=(int)(Math.ceil((b1+b2+b3+b4)/4));
				int c=(int)(Math.ceil((c1+c2+c3)/3));
				int d=(int)(Math.ceil((d1+d2+d3)/3));
				int totres=(int)(Math.ceil((a+b+c+d)/4));
				int totst=rs.getInt(15);
				
				String fquery="select fname,dept from faculty where fid=(select fid from femap where mapid=?)";
				PreparedStatement fst=con.prepareStatement(fquery);
				fst.setString(1, mapid);
				ResultSet frs=fst.executeQuery();
				String fname=new String();
				String dept=new String();
				if(frs.next())
				{
					fname=frs.getString(1);
					dept=frs.getString(2);
				}
				
				
				String totop=totst+"";
                 				
				//System.out.println(sttotal);
				
				String cls=class1;
				String brch="";
				String subid=mapid.split("-")[0];
				String subname="";
				if(dept.equals("M.B.A"))
					subname=databean.getFESubjectName(subid);
				else
					subname="FOUNDATION ELECTIVE-"+databean.getFESubjectName(subid);	
				insertQuery="insert into facultyfeedback values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				
				PreparedStatement iq=con.prepareStatement(insertQuery);
				
				iq.setString(1, cls);
				iq.setString(2, subname);
				iq.setString(3, "");
				iq.setInt(4, a1);
				iq.setInt(5, a2);
				iq.setInt(6, a3);
				iq.setInt(7, b1);
				iq.setInt(8, b2);
				iq.setInt(9, b3);
				iq.setInt(10, b4);
				iq.setInt(11, c1);
				iq.setInt(12, c2);
				iq.setInt(13, c3);
				iq.setInt(14, d1);
				iq.setInt(15, d2);
				iq.setInt(16, d3);
				iq.setInt(17, a);
				iq.setInt(18, b);
				iq.setInt(19, c);
				iq.setInt(20, d);
				iq.setInt(21, totres);
				iq.setString(22, totop);
				iq.setString(23, ay1);
				iq.setString(24, dept);
							
				iq.setString(25,fname);
				iq.executeUpdate();
				
			}
					
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		  new DBConnection().releaseDatabaseConnection(con);
		
	}
	public void loadOEData(String class1,String ay1)
	{
	
		try {
			con=new DBConnection().getDatabaseConnection();
			con.createStatement().executeUpdate("delete from facultyfeedback");
			
			String query="";
			
				query="SELECT f.mapid,ceil(sum(a1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b4)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(c1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c3)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d3)/(cast((count(f.sno)*5) as decimal))*100),count(f.sno) from feedback f where  f.mapid in (select mapid from oemap where ay=?)  group by f.mapid";
			
			PreparedStatement ps=con.prepareStatement(query);
			
			//System.out.println(fname+dept);
			ps.setString(1, ay1);
			ResultSet rs=ps.executeQuery();
			String insertQuery=new String();
			while(rs.next())
			{
				String mapid=rs.getString(1);
				int a1=rs.getInt(2);
				int a2=rs.getInt(3);
				int a3=rs.getInt(4);
				int b1=rs.getInt(5);
				int b2=rs.getInt(6);
				int b3=rs.getInt(7);
				int b4=rs.getInt(8);
				int c1=rs.getInt(9);
				int c2=rs.getInt(10);
				int c3=rs.getInt(11);
				int d1=rs.getInt(12);
				int d2=rs.getInt(13);
				int d3=rs.getInt(14);
				int a=(int)(Math.ceil((a1+a2+a3)/3));
				int b=(int)(Math.ceil((b1+b2+b3+b4)/4));
				int c=(int)(Math.ceil((c1+c2+c3)/3));
				int d=(int)(Math.ceil((d1+d2+d3)/3));
				int totres=(int)(Math.ceil((a+b+c+d)/4));
				int totst=rs.getInt(15);
				
				String fquery="select fname,dept from faculty where fid in (select fid from oemap where mapid=?)";
				PreparedStatement fst=con.prepareStatement(fquery);
				fst.setString(1, mapid);
				ResultSet frs=fst.executeQuery();
				String fname=new String();
				String dept=new String();
				if(frs.next())
				{
					fname=frs.getString(1);
					dept=frs.getString(2);
				}
				
				
				String totop=totst+"";
                 				
				//System.out.println(sttotal);
				
				String cls=class1;
				String brch="";
				String subid=mapid.split("-")[0];
				String subname="";
				
					subname="OPEN ELECTIVE-"+new SubjectDB().getOESubjectName(subid);	
				insertQuery="insert into facultyfeedback values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				
				PreparedStatement iq=con.prepareStatement(insertQuery);
				
				iq.setString(1, cls);
				iq.setString(2, subname);
				iq.setString(3, "");
				iq.setInt(4, a1);
				iq.setInt(5, a2);
				iq.setInt(6, a3);
				iq.setInt(7, b1);
				iq.setInt(8, b2);
				iq.setInt(9, b3);
				iq.setInt(10, b4);
				iq.setInt(11, c1);
				iq.setInt(12, c2);
				iq.setInt(13, c3);
				iq.setInt(14, d1);
				iq.setInt(15, d2);
				iq.setInt(16, d3);
				iq.setInt(17, a);
				iq.setInt(18, b);
				iq.setInt(19, c);
				iq.setInt(20, d);
				iq.setInt(21, totres);
				iq.setString(22, totop);
				iq.setString(23, ay1);
				iq.setString(24, dept);
							
				iq.setString(25,fname);
				iq.executeUpdate();
				
			}
					
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		  new DBConnection().releaseDatabaseConnection(con);
		
	}
	public String getDeptName(String dept)
	{
	   if(dept.equals("I.T"))
		   return "Information Technology(IT)";
		   else if(dept.equals("C.S.E"))
			   return "Computer Science(CSE)";
		   else if(dept.equals("E.C.E"))
			   return "Electronics and Communications(ECE)";
		   else if(dept.equals("E.E.E"))
			   return "Electrical and Electronics(EEE)";
		   else if(dept.equals("MECH"))
			   return "Mechanical";
		   else if(dept.equals("CIVIL"))
			   return "Civil";
		   else if(dept.equals("M.C.A"))
			   return "MCA";
		   else if(dept.equals("M.B.A"))
			   return "MBA";
		   else if(dept.equals("Basic Science"))
			   return "Basic Science(BS)";
	   return "";
	    }

}
