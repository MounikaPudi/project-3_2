package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Vector;

public class FBSFetchDataBean {
	
	
	PreparedStatement psmt;
	Statement st;
	DBConnection dbc;
		
		
	
	public Vector getSubjectsList(String branch,String year,String sem,String ay,String sec)
	{
		MapSubjectDB sdb=new MapSubjectDB();
		Vector slist=sdb.loadSubjectsList(branch,year,sem,ay,sec);
		
		return slist;
	}
	public Vector getFacultyList(String dept)
	{
		FacultyDB fdb=new FacultyDB();
		Vector flist=fdb.loadFacultyList(dept);
		
		return flist;
		
	}
	public Vector getFEFacultyList(String fe)
	{
		FacultyDB fdb=new FacultyDB();
		Vector flist=fdb.loadFEFacultyList(fe);
		
		return flist;
		
	}
	public Vector getOEFacultyList(String fe,String branch)
	{
		FacultyDB fdb=new FacultyDB();
		Vector flist=fdb.loadOEFacultyList(fe,branch);
		
		return flist;
		
	}
	public String getFacultyName(String fid)
	{
		FacultyDB fdb=new FacultyDB();
		String fname=fdb.getFacultyName(fid);
		
		return fname;
		
	}
	
	public String getSubjectName(String subj)
	{
		SubjectDB fdb=new SubjectDB();
		String sname=fdb.getSubjectName(subj);
		
		return sname;
		
	}
	public Vector getShortNames(Vector subjects)
	{
		Vector shrtnames=new Vector();
	    
		for(int i=0;i<subjects.size();i++)
		{
			Vector totsub=(Vector)subjects.elementAt(i);
			Subject sub=(Subject)totsub.elementAt(0);
			shrtnames.addElement(sub.getShrtname());
		}
		return shrtnames;

	}
	public Vector getSubjectIDs(Vector subjects)
	{
		Vector subids=new Vector();
	    
		for(int i=0;i<subjects.size();i++)
		{
			Vector totsub=(Vector)subjects.elementAt(i);
			Subject sub=(Subject)totsub.elementAt(0);
			subids.addElement(sub.getSid());
		}
		return subids;

	}
	public Vector getAMarks()
	{
		Vector aMarks=new Vector();
		
		
		Vector e=new Vector();
		Vector g=new Vector();
		Vector s=new Vector();
		Vector us=new Vector();
		
		Vector dum=new Vector();
		dum.addElement("");
		dum.addElement("");
		
		e.addElement("10");
		e.addElement("Excellent");
		
		g.addElement("8");
		g.addElement("Good");
		
		s.addElement("5");
		s.addElement("Satisfactory");
		
		us.addElement("2");
		us.addElement("UnSatisfactory");
		
	    aMarks.addElement(dum);
		aMarks.addElement(e);
	    aMarks.addElement(g);
	    aMarks.addElement(s);
	    aMarks.addElement(us);
	    
	    return aMarks;
	}
	
	public Vector getBMarks()
	{
		Vector bMarks=new Vector();
		
		Vector e=new Vector();
		Vector g=new Vector();
		Vector s=new Vector();
		Vector us=new Vector();
		
		Vector dum=new Vector();
		dum.addElement("");
		dum.addElement("");
		
		e.addElement("10");
		e.addElement("Excellent");
		
		g.addElement("8");
		g.addElement("Good");
		
		s.addElement("5");
		s.addElement("Satisfactory");
		
		us.addElement("2");
		us.addElement("UnSatisfactory");
		
		bMarks.addElement(dum);
		bMarks.addElement(e);
	    bMarks.addElement(g);
	    bMarks.addElement(s);
	    bMarks.addElement(us);
	    
	    return bMarks;
	}
	public Vector getCMarks()
	{
		Vector cMarks=new Vector();
		
		Vector e=new Vector();
		Vector g=new Vector();
		Vector s=new Vector();
		Vector us=new Vector();
		
		Vector dum=new Vector();
		dum.addElement("");
		dum.addElement("");
		
		e.addElement("5");
		e.addElement("Excellent");
		
		g.addElement("4");
		g.addElement("Good");
		
		s.addElement("3");
		s.addElement("Satisfactory");
		
		us.addElement("1");
		us.addElement("UnSatisfactory");
		
	    cMarks.addElement(dum);
		cMarks.addElement(e);
	    cMarks.addElement(g);
	    cMarks.addElement(s);
	    cMarks.addElement(us);
	    
	    return cMarks;
	}
	public Vector getDMarks()
	{
		Vector dMarks=new Vector();
		
		Vector e=new Vector();
		Vector g=new Vector();
		Vector s=new Vector();
		Vector us=new Vector();
		
		Vector dum=new Vector();
		dum.addElement("");
		dum.addElement("");
		
		e.addElement("5");
		e.addElement("Excellent");
		
		g.addElement("4");
		g.addElement("Good");
		
		s.addElement("3");
		s.addElement("Satisfactory");
		
		us.addElement("1");
		us.addElement("UnSatisfactory");
		
	    dMarks.addElement(dum);
		dMarks.addElement(e);
	    dMarks.addElement(g);
	    dMarks.addElement(s);
	    dMarks.addElement(us);
	    
	    return dMarks;
	}
  public Vector getFacultyVector(Vector subjects)
  {
	  Vector flist=new Vector();
	    
		for(int i=0;i<subjects.size();i++)
		{
			Vector totsub=(Vector)subjects.elementAt(i);
			Faculty flty=(Faculty)totsub.elementAt(1);
			flist.addElement(flty.getFname());
		}
		return flist;
  }
  Object getMark(String mark,String code)
  {
	  if(code.equals("A")||code.equals("B"))
	  {
		  if(mark.equals("10"))
			  return "Excellent";
		  else if(mark.equals("8"))
			  return "Good";
		  else if(mark.equals("5"))
			  return "Satisfactory";
		  else if(mark.equals("2"))
			  return "UnSatisfactory";
		  
	  }
	  else if(code.equals("C")||code.equals("D"))
	  {
		  if(mark.equals("5"))
			  return "Excellent";
		  else if(mark.equals("4"))
			  return "Good";
		  else if(mark.equals("3"))
			  return "Satisfactory";
		  else if(mark.equals("1"))
			  return "UnSatisfactory";
	  }
	  return "";
	  
  }
  public Vector createMarkVector(String mark,String code)
  {
	  Vector m=new Vector();
	  m.addElement(mark);
	  m.addElement(getMark(mark,code));
	  return m;
	  
  }
	public boolean deleteMappedSubject(String subjid,String sec)
	{
		MapSubjectDB sdb=new MapSubjectDB();
		boolean res=sdb.deleteMapping(subjid,sec);
		return res;
		
		
	}
	public Vector getMappedSubjectsList(String branch,String year,String sem,String ay,String sec)
	{
		MapSubjectDB sdb=new MapSubjectDB();
		Vector slist=sdb.loadMappedSubjectsList(branch,year,sem,ay,sec);
		
		return slist;
	}
	public String getMappedFaculty(String subj,String sec)
	{
		MapSubjectDB sdb=new MapSubjectDB();
		String fid=sdb.loadMappedFaculty(subj,sec);
		
		return fid;
	}
	public String getDept(String fid)
	{
		FacultyDB fdb=new FacultyDB();
		String dept=fdb.getFacultyDept(fid);
		return dept;
	}
	public Vector getAttemptedList()
	{
		FeedBackDB fdb=new FeedBackDB();
		Vector list=fdb.getList("attempt");
		return list;
		
	}
	public Vector getNotAttemptList()
	{
		FeedBackDB fdb=new FeedBackDB();
		Vector list=fdb.getList("not attempt");
		return list;
		
	}
	public boolean deleteStudent(String sno)
	{
		StudentDB stdnt=new StudentDB();
		int res=stdnt.deleteStudentInfo(sno);
		if(res>0)
			return true;
		else
			return false;
		
	}
	public boolean deleteOEfeedback()
	{
		FeedBackDB stdnt=new FeedBackDB();
		int res=stdnt.deleteOEfeedback();
		if(res>0)
			return true;
		else
			return false;
		
	}
	public boolean deleteFeedback()
	{
		FeedBackDB stdnt=new FeedBackDB();
		int res=stdnt.deleteFeedback();
		if(res>0)
			return true;
		else
			return false;
		
	}
	public boolean deleteSubjects(String sem)
	{
		SubjectDB stdnt=new SubjectDB();
		int res=stdnt.deleteSubjects(sem);
		if(res>0)
			return true;
		else
			return false;
		
	}
	public boolean yearWiseDelete(String year,String branch)
	{
		StudentDB stdnt=new StudentDB();
		int res=stdnt.deleteStudentYearwise(year,branch);
		if(res>0)
			return true;
		else
			return false;
		
	}	
	public boolean classDelete(String branch,String year,String sem,String sec)
	{
		StudentDB stdnt=new StudentDB();
		int res=stdnt.classDeletion(branch,year,sem,sec);
		if(res>0)
			return true;
		else
			return false;
	}
	
	public int promoteStudents(String branch,String year,String demotelist)
	{
		StudentDB stdnt=new StudentDB();
		int res=stdnt.promotions(branch,year,demotelist);
	    return res;   	
	}
	public int promoteStudentList(String fromyear,String fromsem,String toyear,String tosem)
	{
		StudentDB stdnt=new StudentDB();
		int res=stdnt.doPromotions(fromyear,fromsem,toyear,tosem);
		return res;   	
	}
		
	
	public boolean deleteFaculty(String fno)
	{
		FacultyDB stdnt=new FacultyDB();
		int res=stdnt.deleteFacultyInfo(fno);
		if(res>0)
			return true;
		else
			return false;
		
	}
	
	public String getFESubjectName(String sid)
	{
		
		if(sid.equals("UGCS2T03"))
			return "INTRODUCTION TO COMPUTERS AND PROBLEM SOLVING";
		else if(sid.equals("UGBS1T0518"))
			return "ENGINEERING CHEMISTRY";
		else if(sid.equals("UGBS1T0418"))
			return "APPLIED CHEMISTRY";
		else if(sid.equals("UGEE2T01"))
			return "BASIC ELECTRICAL ENGINEERING";
		else if(sid.equals("UGEE2T0218"))
			return "BASIC ELECTRICAL & ELECTRONICS ENGINEERING";
		else if(sid.equals("PGMB3T06"))
			return "Retail Management";
		else if(sid.equals("PGMB3T07"))
			return "Advertising and Brand Management";
		else if(sid.equals("PGMB3T08"))
			return "Security Analysis and Portfolio Management";
		else if(sid.equals("PGMB3T09"))
			return "Financial Markets and Services";
		
		return "";
	}
}
