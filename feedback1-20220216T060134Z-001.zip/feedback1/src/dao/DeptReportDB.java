package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

public class DeptReportDB {
	java.sql.Connection con;
	Statement st;
	ResultSet rs;
	private String acayear;
	
	public DeptReportDB()
	{
	//	con=new DBConnection().getDatabaseConnection();
	}
	
	public Hashtable loadData(Hashtable fnames,String dept)
	{
		
	Hashtable facultydata=new Hashtable();
	
		try {
			con=new DBConnection().getDatabaseConnection();
			con.createStatement().executeUpdate("delete from facultyfeedback");
			
			String query="SELECT f.mapid,ceil(sum(a1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b4)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(c1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c3)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d3)/(cast((count(f.sno)*5) as decimal))*100),count(f.sno) from feedback f,mapsubjects m,subjects s where m.fid=? and m.mapid=f.mapid and m.sid=s.sid  group by f.mapid";

	//		Enumeration list=fnames.keys();
	
			
		    Vector v = new Vector(fnames.keySet());
		    Collections.sort(v);
		    
		   

		    Enumeration list = v.elements();
			while(list.hasMoreElements())
			{
			 String fid=(String) list.nextElement();
			 String fname=(String) fnames.get(fid);
			
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, fid);
			//ps.setString(2, dept);
			//ps.setString(2, sem1);
			//System.out.println(fname+dept);
			ResultSet rs=ps.executeQuery();
			String insertQuery=new String();
			Vector subjects=new Vector();
			while(rs.next())
			{
				String mapid=rs.getString(1);
				int a1=rs.getInt(2);
				int a2=rs.getInt(3);
				int a3=rs.getInt(4);
				int b1=rs.getInt(5);
				int b2=rs.getInt(6);
				int b3=rs.getInt(7);
				int b4=rs.getInt(8);
				int c1=rs.getInt(9);
				int c2=rs.getInt(10);
				int c3=rs.getInt(11);
				int d1=rs.getInt(12);
				int d2=rs.getInt(13);
				int d3=rs.getInt(14);
				int a=(int)(Math.ceil((a1+a2+a3)/3));
				int b=(int)(Math.ceil((b1+b2+b3+b4)/4));
				int c=(int)(Math.ceil((c1+c2+c3)/3));
				int d=(int)(Math.ceil((d1+d2+d3)/3));
				int totres=(int)(Math.ceil((a+b+c+d)/4));
				int totst=rs.getInt(15);
				String subquery="select section,s.shortname,s.branch,s.year,s.sem,s.ay from mapsubjects m,subjects s where mapid=? and m.sid=s.sid";
				PreparedStatement pq=con.prepareStatement(subquery);
				pq.setString(1,mapid);
				ResultSet sub=pq.executeQuery();
				String subname=new String();
				String branch=new String();
				String year=new String();
				String sem=new String();
				String section=new String();
				String ay=new String();
				
				if(sub.next())
				{
					 subname=sub.getString(2);
					 branch=sub.getString(3);
					 year=sub.getString(4);
					 sem=sub.getString(5);
					 section=sub.getString(1);
					ay=sub.getString(6);
					acayear=ay;
				}
				
				String cls=year+" - "+sem+" "+branch +" - "+section;
				//String brch=branch+" - "+section;
				Vector subject=new Vector();
				subject.add(subname);
				subject.add(cls);
				subject.add(new Integer(totres));
				subject.add(new Integer(totst));
				subjects.add(subject);
			}
	    facultydata.put(fid, subjects);
			}
		}
		catch(Exception e){System.out.println(e);}
				
		facultydata.put("ay",acayear);
		new DBConnection().releaseDatabaseConnection(con);
		return facultydata;
	}
	public String getDeptName(String dept)
	{
	   if(dept.equals("I.T"))
		   return "Information Technology(IT)";
		   else if(dept.equals("C.S.E"))
			   return "Computer Science(CSE)";
		   else if(dept.equals("E.C.E"))
			   return "Electronics and Communications(ECE)";
		   else if(dept.equals("E.E.E"))
			   return "Electrical and Electronics(EEE)";
		   else if(dept.equals("MECH"))
			   return "Mechanical";
		   else if(dept.equals("CIVIL"))
			   return "Civil";
		   else if(dept.equals("M.C.A"))
			   return "MCA";
		   else if(dept.equals("M.B.A"))
			   return "MBA";
		   else if(dept.equals("Basic Science"))
			   return "Basic Science(BS)";
	   return "";
	    }

}
