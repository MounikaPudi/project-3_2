package dao;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import dao.DBConnection;
import dao.Faculty;
import dao.Student;
import dao.StudentData;
import dao.Subject;


public class StudentDataDB {

	java.sql.Connection con;
	Statement st;
	ResultSet rs;

	public StudentDataDB()
	{
//		con=new DBConnection().getDatabaseConnection();
	}
	public StudentData loadStdntData(String studentNo) 
	{
		Student loginStudent=getStudentData(studentNo);
		StudentData stdata=new StudentData();
		stdata.setStdnt(loginStudent);
		
		Vector subjects=getSubjects(loginStudent);
		
		stdata.setSubjects(subjects);
		
		return stdata;
	}
	public Vector getSubjects(Student stdnt)
	{
		Vector totalSubjects=new Vector();
		
		String query="select * from subjects where branch=? and year=? and sem=?";
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, stdnt.getBranch());
			psmt.setString(2,stdnt.getYear());
			psmt.setString(3,stdnt.getSem());
			ResultSet rs=psmt.executeQuery();
			
			while(rs.next())
			{
				Subject subj=new Subject();
				subj.setSid(rs.getString(1));
				subj.setSname(rs.getString(2));
				subj.setShrtname(rs.getString(8));
				subj.setBranch(rs.getString(3));
				subj.setYear(rs.getString(4));
				subj.setSem(rs.getString(5));
				subj.setCode(rs.getInt(6));
				subj.setAy(rs.getString(7));
				
				String fquery="select * from faculty where fid=(select fid from mapsubjects where sid=? and section=?)";
				PreparedStatement fpsmt=con.prepareStatement(fquery);;
				fpsmt.setString(1,subj.getSid());
				fpsmt.setString(2, stdnt.getSection());
				ResultSet frs=fpsmt.executeQuery();
				Faculty fty=new Faculty();
				if(frs.next())
				{
					fty.setFid(frs.getString(1));
					fty.setFname(frs.getString(2));
					fty.setDept(frs.getString(3));
					
				}
				String mapquery="select mapid from mapsubjects where sid=? and section=?";
				PreparedStatement mappsmt=con.prepareStatement(mapquery);;
				mappsmt.setString(1,subj.getSid());
				mappsmt.setString(2, stdnt.getSection());
				ResultSet maprs=mappsmt.executeQuery();
				String mapid=new String();
				if(maprs.next())
				{
				  	mapid=maprs.getString(1);
				}
				
				Vector subject=new Vector();
				subject.addElement(subj);
				subject.addElement(fty);
				subject.addElement(mapid);
				totalSubjects.addElement(subject);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return totalSubjects;
	}
	public Student getStudentData(String studentNo)
	{
		Student loginStudent=new Student();
		String stquery="select * from students where sno=?";
		
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement stpsmt=con.prepareStatement(stquery);
			stpsmt.setString(1, studentNo);
			ResultSet rstdata=stpsmt.executeQuery();
			if(rstdata.next())
			{
				loginStudent.setSno(rstdata.getString(1));
				loginStudent.setSname(rstdata.getString(2));
				loginStudent.setBranch(rstdata.getString(3));
				loginStudent.setSection(rstdata.getString(4));
				loginStudent.setYear(rstdata.getString(5));
				loginStudent.setSem(rstdata.getString(6));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return loginStudent;
	}
}
