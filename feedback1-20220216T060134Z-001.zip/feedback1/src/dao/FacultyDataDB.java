package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class FacultyDataDB {

	java.sql.Connection con;
	Statement st;
	ResultSet rs;

	public FacultyDataDB()
	{
		//con=new DBConnection().getDatabaseConnection();
	}
	public FacultyData loadFacultyData(String fid) 
	{
		Faculty loginFaculty=getFacultyData(fid);
		FacultyData ftdata=new FacultyData();
		ftdata.setFaculty(loginFaculty);
		
		Vector subjects=getHandledSubjects(loginFaculty);
		
		ftdata.setSubjects(subjects);
		
		
		return ftdata;
	}
	public Vector getHandledSubjects(Faculty faculty)
	{
		Vector handledSubjects=new Vector();
		
		
		String query="select s.sid,s.subname,s.branch,s.year,s.sem,s.code,s.ay,s.shortname,m.mapid,m.section,m.ay from subjects s,mapsubjects m where fid=? and m.sid=s.sid";
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement psmt=con.prepareStatement(query);
			psmt.setString(1, faculty.getFid());
			ResultSet rs=psmt.executeQuery();
			
			while(rs.next())
			{
				Subject subj=new Subject();
				subj.setSid(rs.getString(1));
				subj.setSname(rs.getString(2));
				subj.setShrtname(rs.getString(8));
				subj.setBranch(rs.getString(3));
				subj.setYear(rs.getString(4));
				subj.setSem(rs.getString(5));
				subj.setCode(rs.getInt(6));
				subj.setAy(rs.getString(7));
			
				MapSubject fty=new MapSubject();
				fty.setMapid(rs.getString(9));
				fty.setFid(faculty.getFid());
				fty.setSubjid(subj.getSid());
				fty.setSec(rs.getString(10));
				fty.setAy(rs.getString(11));
			
				Vector subject=new Vector();
				subject.addElement(subj);
				subject.addElement(fty);
				handledSubjects.addElement(subject);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseConnection(con);
		return handledSubjects;
	}
	public Faculty getFacultyData(String fid)
	{
		Faculty loginFaculty=new Faculty();
		String stquery="select * from faculty where fid=?";
		
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement stpsmt=con.prepareStatement(stquery);
			stpsmt.setString(1, fid);
			ResultSet rstdata=stpsmt.executeQuery();
			if(rstdata.next())
			{
				loginFaculty.setFid(rstdata.getString(1));
				loginFaculty.setFname(rstdata.getString(2));
				loginFaculty.setDept(rstdata.getString(3));
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return loginFaculty;
	}

}
