package dao;

import java.util.Calendar;
import java.util.*;
import java.util.Date;
import java.util.GregorianCalendar;

public class CurDate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calendar cal = new GregorianCalendar();
		  int month = cal.get(Calendar.MONTH);
		  int year = cal.get(Calendar.YEAR);
		  int day = cal.get(Calendar.DAY_OF_MONTH);

		  String strdate=day+"."+month+"."+year;
		// System.out.println(strdate);
		// System.out.println(new Date().toString());
		// System.out.println(new Date().getDay());
		// System.out.println(new Date().getMonth());
		// System.out.println(new Date().getYear());
		 FBSMiscUtilitiesBean fs= new FBSMiscUtilitiesBean();;
		 String dt=fs.getSystemDate("dd/MM/yyyy");
		 System.out.println(strdate);
		 
		 
	}

}
