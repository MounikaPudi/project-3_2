package dao;



public class Subject {
String sid;
String sname;
String shrtname;
String branch;
String year;
String sem;
int code;
String ay;
public String getShrtname() {
	return shrtname;
}
public void setShrtname(String shrtname) {
	this.shrtname = shrtname;
}

public String getAy() {
	return ay;
}
public void setAy(String ay) {
	this.ay = ay;
}
public String getSid() {
	return sid;
}
public void setSid(String sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public String getYear() {
	return year;
}
public void setYear(String year) {
	this.year = year;
}
public String getSem() {
	return sem;
}
public void setSem(String sem) {
	this.sem = sem;
}
public int getCode() {
	return code;
}
public void setCode(int code) {
	this.code = code;
}

	


}
