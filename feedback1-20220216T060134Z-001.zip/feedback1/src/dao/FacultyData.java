package dao;

import java.util.Vector;

public class FacultyData {
	
	Faculty faculty;
	Vector subjects;
	
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	public Vector getSubjects() {
		return subjects;
	}
	public void setSubjects(Vector subjects) {
		this.subjects = subjects;
	}
	
	

}
