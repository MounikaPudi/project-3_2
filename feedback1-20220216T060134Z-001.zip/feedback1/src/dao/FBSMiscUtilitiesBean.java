package dao;

import javax.servlet.http.*;
import javax.servlet.*;
import java.util.*; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.*;
public class FBSMiscUtilitiesBean
{
    int scrollDifference = 50;
    
    public boolean isEqual(String s1, String s2)
    {
        s1 = noNull(s1);
        s2 = noNull(s2);
        return s1.equals(s2);
    }
    
    public String getRecordsNotFoundMessage()
    {
        String result = "<TABLE><TR><TD CLASS = \"ERRORMESSAGE\" ALIGN = \"CENTER\">No Records Found</TD></TR></TABLE>";
        return result;
    }

    public String getRequiredFieldMessage()
    {
        String result = "<TABLE><TR><TD CLASS = \"FOOTERMESSAGE\" ALIGN = \"CENTER\">* indicates Required Field</TD></TR></TABLE>";
        return result;
    }

    public int getScrollDifference()
    {
        return scrollDifference;
    }
    
    public String getYNCode(String value)
    {
        return getYNCode(value,"No");
    }
    
    public String getYNCode(String value, String defaultCode)
    {
        if (isNull(value)) return defaultCode;
        if (((value.toUpperCase()).trim()).equals("Y")) return "Yes";
        return "No";
    }

    public double getDecimalValue(String value)
    {
        if (isNull(value)) return 0;
        value = getNumber(value);
        try
        {
            double d = (new Double(value)).doubleValue();
            return d;
        }
        catch(Exception e)
        {
            return 0;
        }
    }
    
    public String formatDecimal(String value,boolean includeDollar)
    {
        String Format = "###,###,###,##0.00";
        String frmvalue = "";
        try
        {
            value = getNumber(value);
            frmvalue = formatDecimal(value,Format);
            if (isNull(frmvalue)) frmvalue = "0.00";
        }
        catch(Exception e)
        {
            frmvalue = "0.00";
        }
        
        if (includeDollar)
        {
            frmvalue = "$" + frmvalue;
        }
        return frmvalue;
    }

    public String formatDecimal(String Value, String Format)
    throws Exception
    {
        if (Value == null) return Value;
        if (Format == null) return Value;
        if (Value.trim().length() < 1) return Value;

        double d = (new Double(Value)).doubleValue();
        DecimalFormat df = new DecimalFormat(Format);
        return df.format(d);
    }

    public int getCurrentPageNumber(String pageNumber)
    {
        if (pageNumber == null) return 1;
        if (pageNumber.trim().length() < 1) return 1;
        try
        {
            return Integer.parseInt(pageNumber);
        }
        catch(Exception e)
        {
            return 1;
        }
    }
    
    public String getTopSearchActionMessage(int count, boolean searchRecordFound)
    {
        String resultMessage = "";
        if (searchRecordFound)
        {
            if (count <= 0) resultMessage = "No Records Found";
            else
            if (count > 0) resultMessage = "See below for Search Results";
        }
        else
        {
            resultMessage = "";
        }
        String result = "<CENTER><P><B><FONT COLOR=\"red\" FACE=\"Arial\">" + resultMessage + "</FONT></B></CENTER>";
        return result;
    }

    public String getBottomSearchActionMessage(int count, boolean searchRecordFound)
    {
        String resultMessage = "";
        if (searchRecordFound)
        {
            if (count <= 0) resultMessage = "";
            else
            if (count == 1) resultMessage = "1 Record Found";            
            else
            if (count > 0) resultMessage = count + " Records Found";
        }
        else
        {
            resultMessage = "";
        }
        String result = "<CENTER><P><B><FONT COLOR=\"red\" FACE=\"Arial\">" + resultMessage + "</FONT></B></CENTER>";
        return result;
    }

    public int getStartRecordIndex(String pageNumber)
    {
        int currpagenumber = getCurrentPageNumber(pageNumber);
        return ((currpagenumber  - 1) * scrollDifference + 1);
    }
    
    public int getEndRecordIndex(String pageNumber)
    {
        int currpagenumber = getCurrentPageNumber(pageNumber);
        return (currpagenumber * scrollDifference);
    }
    
    public String getSystemDate(String OutputFormat)
    {
        return (new FormatDate()).getSystemDate(OutputFormat);
    }

    public String getSystemDatetime()
    {
        String OutputFormat = "MM/dd/yyyy hh:mm:ss a, z";
        return (new FormatDate()).getSystemDate(OutputFormat);
    }

    public String getSystemDate()
    {
        String OutputFormat = "MM/dd/yyyy";
        return (new FormatDate()).getSystemDate(OutputFormat);
    }
    
    public String getNumber(String value)
    {
        if (value == null) return value;
        value = replaceString(value,",","",true);
        value = replaceString(value," ","",true);
        return value;
    }

    public String getCheckBoxSelectionIndicator(String Value)
    {
        if (Value == null) return "";
        if (Value.equals("Y")) return "CHECKED";
        else
        return "";
    }

    public String getRadioSelectionIndicator(String ExpectedValue, String Value)
    {
        if (ExpectedValue == null) return "";
        if (Value == null) return "";
        if (ExpectedValue.equals(Value))
        return "CHECKED";
        else
        return "";
    }

    public Vector removeElementFromVector(Vector aVector, String Element)
    {
        if (aVector == null) return aVector;
        if (Element == null) return aVector;

        Vector resultVector = new Vector();
        for (int index = 0; index < aVector.size(); index++)
        {
            String line = aVector.elementAt(index) + "";
            if (!line.equals(Element))
            {
                resultVector.addElement(line);
            }
        }
        return resultVector;
    }

    public String getElementAt(Vector inputVector, int row, int col)
    {
        try
        {
            Vector aVector = (Vector)inputVector.elementAt(row);
            String result = (String)aVector.elementAt(col);
            return result;
        }
        catch(Exception e)
        {
            return null;
        }
    }

	public String makeNull(String value)
	{
	    if (value == null) return null;
	    if (value.trim().length() < 1) return null;
	    return value;
	}

    public boolean isElementInVector(Vector aVector, String element)
    {
        if (aVector==null) return false;
        if (aVector.size() < 1) return false;
        if (element == null) return false;
        for (int index = 0; index < aVector.size(); index++)
        {
            String vectorElement = aVector.elementAt(index) + "";
            if (vectorElement.equals(element))
            {
                return true;
            }
        }
        return false;
    }
    
    public boolean isValidDate(String s_date, String s_Format)
    {
        try
        {
            java.sql.Date result = (new FormatDate()).getSQLDateObject(s_date, s_Format);
            if (result == null) return false;
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }
    
    public boolean isValidNumber(String sNumber)
    {
        try
        {
            int no = Integer.parseInt(sNumber);
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
    }
    
    

    public void forwardToPage(HttpServletRequest req, HttpServletResponse res, String S_URL)
    {
        try
        {
                res.sendRedirect(S_URL);        
                return;
        }
        catch(Exception e)
        {
            e.printStackTrace(); 
        }
    }

    public static String noNullReplaceCodes(String value, boolean htmlspace)
    {
        value = noNull(value,htmlspace);
        value = replaceString(value, "\n","<BR>",true);
        return value;
    }
    
    public static String noNull(Object value, boolean htmlspace)
    {
        String result = noNull(value);
        
        if (htmlspace)
        {
            if (result.equals(""))
            result = "&nbsp;";
        }
        return result.trim();
    }
    
    public String printIfNotNull(String value, String printValue)
    {
        if (!isNull(value)) return printValue;
        return "";
    }
    
    public static boolean isNull(Object value)
    {
        if (value == null) return true;
        String svalue = noNull(value, false);
        if (svalue.trim().length() > 0)
        {
            return false;
        }
        return true;
    }
    
    public void writeToSession(HttpServletRequest req, HttpServletResponse res, String SessVar, Object value)
    {
        if (!isNull(value))
        {
            HttpSession session = req.getSession(true);
            session.putValue(SessVar, value);
        }
        else
        {
            HttpSession session = req.getSession(true);
            session.removeValue(SessVar);
        }
    }
    
    public String getFromSession(HttpServletRequest req, HttpServletResponse res, String SessVar)
    {
        String resultMessage = "";
        
        HttpSession session = req.getSession(true);
        Object O_Message = session.getValue(SessVar);
        if (O_Message == null) return "";
        
        String Message = O_Message.toString();
        if (Message == null) return "";
        if (Message.trim().length() < 1) return "";
        
        resultMessage = Message;
        return resultMessage;
    }
    
	public static String  replaceString(String Source, String Old, String New, boolean repeat)
	{
		if (Source == null) return "";
		if (Old == null) return Source;
		if (New == null) return Source;
		if (Old.equals(New)) return Source;

		int index = Source.indexOf(Old);
		if (index < 0) return Source;

		String firstPart = Source.substring(0,index);
		String finalPart = Source.substring(index + Old.length());

		if (repeat)
		{
			if ((finalPart != null)&&(finalPart.length() > 0))
				return (firstPart + New + replaceString(finalPart, Old, New, repeat));
		}
		return (firstPart + New + finalPart);
	}
    

    public static String noNullNoDecode(Object value)
    {
        if (value == null) return "";
        String svalue = value + "";
        if (svalue == null) return "";
        return svalue.trim();
    }

    public static String noNull(Object value)
    {
        if (value == null) return "";
        return noNull(value + "");
    }

    public static String noNull(String value)
    {
        if (value == null) return "";
        value = replaceString(value, "\"", "&quot;", true);
        return value.trim();
    }
    
    public static String noNull(String value, String defaultValue)
    {
    	String result = noNull(value);
    	if (result.length() < 1) return defaultValue;
    	return result;
    }    

    public void setActionMessage(HttpServletRequest req, HttpServletResponse res, String MessageCode, String Message)
    {
        HttpSession session = req.getSession(true);
        session.putValue(MessageCode, Message);
    }

    public void clearActionMessage(HttpServletRequest req, HttpServletResponse res, String MessageCode)
    {
        HttpSession session = req.getSession(true);
        session.putValue(MessageCode, "");
    }

    public String getActionMessage(HttpServletRequest req, HttpServletResponse res, String MessageCode)
    {
        String resultMessage = "";
        
        HttpSession session = req.getSession(true);
        Object O_Message = session.getValue(MessageCode);
        if (O_Message == null) return resultMessage;
        
        String Message = O_Message.toString();
        if (Message == null) return resultMessage;
        if (Message.trim().length() < 1) return resultMessage;
        
        resultMessage = Message;
        return resultMessage;
    }

    public StringBuffer printSelectCodeForDoubles(StringBuffer sb, Vector aVectorList, String selectFieldName, String defaultValue, String eventCode)
    {
            sb.append("<SELECT NAME=\"" + selectFieldName + "\" " + eventCode + " >");
            for (int index = 0; index < aVectorList.size(); index++)
            {
                if (defaultValue == null)
                {
                    sb.append("<OPTION VALUE=\"" + getElementAt(aVectorList, index, 0)  + "\">" + getElementAt(aVectorList, index, 1) + "</OPTION>\n");
                }
                else
                {
                    if (getElementAt(aVectorList, index, 0).equals(defaultValue))
                    {
                        sb.append("<OPTION VALUE=\"" + getElementAt(aVectorList, index, 0) + "\" SELECTED>" + getElementAt(aVectorList, index, 1) + "</OPTION>\n");
                    }
                    else
                    {
                        sb.append("<OPTION VALUE=\"" + getElementAt(aVectorList, index, 0) + "\">" + getElementAt(aVectorList, index, 1) + "</OPTION>\n");
                    }
                }
            }
            sb.append("</SELECT>");
            return sb;
    }

    public StringBuffer printSelectMultipleCodeForDoubles(StringBuffer sb, Vector aVectorList, String selectFieldName, String[] defaultValue, String eventCode)
    {
            sb.append("<SELECT NAME=\"" + selectFieldName + "\" " + eventCode + " >");
            for (int index = 0; index < aVectorList.size(); index++)
            {
                if (defaultValue == null)
                {
                    sb.append("<OPTION VALUE=\"" + getElementAt(aVectorList, index, 0)  + "\">" + getElementAt(aVectorList, index, 1) + "</OPTION>\n");
                }
                else
                {
                    if (isWordExistingInArray(defaultValue, getElementAt(aVectorList, index, 0)))
                    {
                        sb.append("<OPTION VALUE=\"" + getElementAt(aVectorList, index, 0) + "\" SELECTED>" + getElementAt(aVectorList, index, 1) + "</OPTION>\n");
                    }
                    else
                    {
                        sb.append("<OPTION VALUE=\"" + getElementAt(aVectorList, index, 0) + "\">" + getElementAt(aVectorList, index, 1) + "</OPTION>\n");
                    }
                }
            }
            sb.append("</SELECT>");
            return sb;
    }
    
    public boolean isWordExistingInArray(String[] list, String value)
    {
        if (list == null) return false;
        if (value == null) return false;
        for (int index = 0; index < list.length; index++)
        {
            if (list[index] == null) continue;
            if (list[index].equals(value)) return true;
        }
        return false;
    }
    
//    String[] getWordsInLines(String SouceString)    

    public String addSearchCondition(String Condition, String Structure, String NullStructure, String columnName, String value)
    {
        String ResultCondition = "";
        if (!isNull(value))
        {
            Structure = replaceString(Structure, "$COLNAME$", columnName, true);
            Structure = replaceString(Structure, "$COLVAL$", value, true);        
            ResultCondition = Structure;
        }
        else
        {
            NullStructure = replaceString(NullStructure, "$COLNAME$", columnName, true);
            NullStructure = replaceString(NullStructure, "$COLVAL$", value, true);
            ResultCondition = NullStructure;            
        }
        return addSearchCondition(Condition, ResultCondition);
    }
    
    public String addSearchCondition(String Condition, String newCondition)
    {
        if (isNull(Condition))
            return newCondition;
        if (isNull(newCondition))
            return Condition;
        return Condition + "AND" + newCondition;
    }
    
    public String addLeadingZeros(String value)
    {
        if (value == null) value = "";
        for (int index = value.length(); index < 5; index++)
        {
            value = "0" + value;
        }
        return value;
    }
    
    public boolean isAlphaNumeric(int val)
    {
        if ((val >= 'A')&&(val <= 'Z')) return true;
        if ((val >= 'a')&&(val <= 'z')) return true;
        if ((val >= '0')&&(val <= '9')) return true;
        return false;
    }
    
    public String generateRandomString(int maxlength)
    {
        String result = "";
        while(true)
        {
            int randomNumber = (int)(Math.random() * 150);  //Generates a random number between 0-150
            if (!isAlphaNumeric(randomNumber)) continue;
            result = result + (char)randomNumber;
            if (result.length() >= maxlength) break;
        }
        return result;
    }        
    
    public String getSelectHeader(String selectName, int visibleRows, int pixels, boolean multiple, String eventCode)
    {
        String multiString = "";
        if (multiple)
        multiString = "MULTIPLE";

        String header = "<SELECT NAME=\"$SELECTNAME$\" SIZE = \"$VISIBLEROWS$\" WIDTH=\"$PIXELSIZE$\" STYLE=\"WIDTH:$PIXELSIZE$px\" $MULTIPLEYN$ $EVENTCODE$>";
        header = replaceString(header,"$SELECTNAME$",selectName,true);
        header = replaceString(header,"$VISIBLEROWS$","" + visibleRows,true);
        header = replaceString(header,"$PIXELSIZE$","" + pixels,true);
        header = replaceString(header,"$MULTIPLEYN$",multiString,true);
        header = replaceString(header,"$EVENTCODE$",eventCode,true);
        return header;
    }
    
    public StringBuffer getSelectListString(StringBuffer sb, Vector aVectorList, String defaultValue, String selectName, int visibleRows, int pixels, boolean multiple, String eventCode)
    {
    	String[] defaultval = new String[1];
    	defaultval[0] = defaultValue;
    	if (defaultValue == null) defaultval = null;
    	return getSelectList(sb, aVectorList, defaultval, selectName, visibleRows, pixels, multiple, eventCode);
    }
    
    public StringBuffer getSelectList(StringBuffer sb, Vector aVectorList, String[] defaultValue, String selectName, int visibleRows, int pixels, boolean multiple, String eventCode)
    {
        sb.append(getSelectHeader(selectName, visibleRows, pixels, multiple, eventCode));
        
        for (int index = 0; index < aVectorList.size(); index++)
        {
            String selectedString = "";
            if (defaultValue != null)
            {
                if (isWordExistingInArray(defaultValue, getElementAt(aVectorList, index, 0)))
                {
                    selectedString = "SELECTED";
                }
            }            
            sb.append("<OPTION VALUE=\"" + getElementAt(aVectorList, index, 0) + "\" " + selectedString + ">" + getElementAt(aVectorList, index, 1) + "</OPTION>\n");
        }
        sb.append("</SELECT>");

        return sb;
    }
    
    public String getInitCap(String value)
    {
        if (value == null) return null;
        value = value.toLowerCase().trim();
        char[] chars = value.toCharArray();         
        boolean setNextCharacterToUpper = true;
        for (int index = 0; index < chars.length; index++)
        {
            if (setNextCharacterToUpper) chars[index] = Character.toUpperCase(chars[index]);
            if (Character.isWhitespace(chars[index]))
            setNextCharacterToUpper = true;
            else setNextCharacterToUpper = false;
        }
        String result = new String(chars);
        return result;
    }
    
    public boolean isUserLoggedIn(HttpServletRequest req, HttpServletResponse res)
    {
        HttpSession session = req.getSession(true);
        Object recordObject = session.getAttribute("LoginFacultyRecord");
        if (recordObject == null) return false;

        String loginID = recordObject.toString();
        
        
        return true;
    }
    
    public void logOffUser(HttpServletRequest req, HttpServletResponse res)
    {
        HttpSession session = req.getSession(true);
		session.setAttribute("AuthenticateActionMessage", "");	        		
        session.setAttribute("LoginFacultyRecord", null);
    }

	public String getAuthenticationActionMessage(HttpServletRequest req, HttpServletResponse res)
    {
        HttpSession session = req.getSession(true);
        Object messageObject = session.getAttribute("AuthenticateActionMessage");
        if (messageObject == null) return "";
        return messageObject.toString();
    }

    public void clearAuthenticMessage(HttpServletRequest req, HttpServletResponse res)
    {
        HttpSession session = req.getSession(true);
		session.setAttribute("AuthenticateActionMessage", "");
    }
    
	public String getStatusMessage(HttpServletRequest req, HttpServletResponse res)
    {
        HttpSession session = req.getSession(true);
        Object messageObject = session.getAttribute("StatusMessage");
        if (messageObject == null) return "";
        return messageObject.toString();
    }
	
	public void clearStatusMessage(HttpServletRequest req, HttpServletResponse res)
    {
        HttpSession session = req.getSession(true);
		session.setAttribute("StatusMessage", "");
    }
	

	public int getMaxScore(int a,int b, int c, String category)
	throws Exception
	{
		if (category.equals("A"))
		{
			return a;
		}
		else if (category.equals("B"))
			{
				return b;
			}
		else
		{
			return c;
		}
	}
	
	public String getRatingValue(int a,int b, int c, String category)
	throws Exception
	{
		if (category.equals("A"))
		{
			return a + "";
		}
		else if (category.equals("B"))
			{
				return b + "";
			}
		else
		{
			return c + "";
		}
	}
	
	public Vector getRatingValues(int a,int b, int c, String category)
	throws Exception
	{
		if (category.equals("A"))
		{
			return getRatingValues(a, false);
		}
		else if (category.equals("B"))
			{
				return getRatingValues(b, false);
			}
		else
		{
			return getRatingValues(c, false);
		}
	}		

	public Vector getRatingValues(int max, boolean insertBlank)
	throws Exception
	{
		Vector aVectorResult = new Vector();
		if (insertBlank)
		{
		    Vector aVector = new Vector();
		    aVector.addElement("");
		    aVector.addElement("");
		    aVectorResult.addElement(aVector);
		}
		for (int index =0; index<=max; index++)
		{
		    Vector aVector = new Vector();
		    aVector.addElement("" + index);
		    aVector.addElement("" + index);
		    aVectorResult.addElement(aVector);			
		}
		return aVectorResult;
	}
}
