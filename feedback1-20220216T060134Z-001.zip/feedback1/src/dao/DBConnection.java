/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 *
 * @author venkatesh
 */
public class DBConnection {
        String dbdriver = null;
	 String dburl = null;
	 String dbuid = null;
	String dbpwd = null;
	    
    public Connection getDatabaseConnection()
    {
        try
        {
        	if (dbdriver == null)
        	{
        		ResourceBundle rb = ResourceBundle.getBundle("DBResource", Locale.getDefault());
        		dbdriver = rb.getString("dbdriver");
        		dburl=rb.getString("dburl");
        		dbuid=rb.getString("dbuid");
        		dbpwd=rb.getString("dbpwd");
        	}

		    Class.forName(dbdriver);
		    Connection con = DriverManager.getConnection(dburl, dbuid, dbpwd);
		    return con;
		}
		catch(Exception e)
		{
		    e.printStackTrace();
		    return null;
		}
    }
    
    	public void releaseDatabaseConnection(Connection con)
	{
		releaseConnection(con);
	}

	public void releaseConnection(Connection con)
        {
        try
        {
            con.close();
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        }
    }
    

}
