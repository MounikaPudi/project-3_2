package dao;
import java.util.*;
import java.text.*;

public class FormatDate
{
    /**
    * Parses year from the given date. Returns all dates in that year in YYYYMMDD format.
    * Input Date should in MM/DD/YYYY format.
    * @return List of Dates in YYYYMMDD format
    * @param S_Date   Input Date with Year Field
    * @param S_Format Input Date format per the codes in java.text.SimpleDateFormat
    * @exception Exception
    * @see java.text.SimpleDateFormat
    */
    public Vector getYearlyCalendar(String S_Date, String S_Format)
    throws Exception
    {
        String S_Year = getFormattedDate(S_Date, S_Format, "yyyy");
        int year = Integer.parseInt(S_Year);
        
        GregorianCalendar gc = new GregorianCalendar();
        gc.set(year, gc.JANUARY, 1);
        
        Vector anVectorYearCalendar = new Vector();
        
        while(true)
        {
            int calYear = gc.get(gc.YEAR);
            if (calYear != year) break;
            
            SimpleDateFormat outputYYYYMMDD = new SimpleDateFormat("yyyyMMdd");
            SimpleDateFormat outputDD = new SimpleDateFormat("dd");
            
            String OutputYYYYMMDD = outputYYYYMMDD.format(gc.getTime());
            String OutputDD = outputDD.format(gc.getTime());
            
            Vector anVector = new Vector();
            anVector.addElement(OutputYYYYMMDD);
            anVector.addElement(OutputDD);
            anVectorYearCalendar.addElement(anVector);
            
            gc.add(gc.DAY_OF_MONTH, 1);
        }
        return anVectorYearCalendar;
    }
    
    public boolean isLastDayInMonth(String S_Date, String InputFormat)
    {
        GregorianCalendar gc = new GregorianCalendar();
        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));
        
        int InitialMonth = gc.get(gc.MONTH);
        gc.add(gc.DAY_OF_MONTH, 1);
        int LaterMonth = gc.get(gc.MONTH);
        
        return (InitialMonth != LaterMonth);
    }
    
    public boolean isSaturday(String S_Date, String InputFormat)
    {
        GregorianCalendar gc = new GregorianCalendar();
        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));
        if (gc.get(gc.DAY_OF_WEEK) == gc.SATURDAY) return true;
        return false;
    }
    
    public int getFirstDayOfMonth(String S_Date, String InputFormat)
    {
        GregorianCalendar gc = new GregorianCalendar();
        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));
        return gc.get(gc.DAY_OF_WEEK);
    }
    
    public String getSystemDate(String OutputFormat)
    {
        SimpleDateFormat outputFormatter = new SimpleDateFormat(OutputFormat);
        return outputFormatter.format(new Date());
    }

    public java.sql.Date getSQLDateObject(String S_Date, String InputFormat, java.sql.Date defaultDate)
    {
        try
        {
            return getSQLDateObject(S_Date, InputFormat);
        }
        catch(Exception e)
        {
            return defaultDate;
        }
    }

    public java.sql.Date getSQLDateObject(String S_Date, String InputFormat)
    throws Exception
    {
        if (S_Date == null) return null;
        if (S_Date.trim().length() < 1) return null;
        GregorianCalendar gc = new GregorianCalendar();
        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));
        
        java.sql.Date sqldate = new java.sql.Date((gc.getTime()).getTime());
        return sqldate; 
    }

    public Date getDateObject(String S_Date, String InputFormat)
    throws Exception
    {
        if (S_Date == null) return null;
        GregorianCalendar gc = new GregorianCalendar();
        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));
        return gc.getTime();
    }
    
    public String getFormattedDate(String S_Date, String InputFormat, String OutputFormat)
    throws Exception
    {
        if (S_Date == null) return null;
        if (S_Date.length() < 1) return null;
        
        GregorianCalendar gc = new GregorianCalendar();

        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));

        SimpleDateFormat outputFormatter = new SimpleDateFormat(OutputFormat);
        return outputFormatter.format(gc.getTime());
    }

    public boolean isFutureDate(String S_Date,  String InputFormat)
    throws Exception
    {
        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        Date idate  = inputFormatter.parse(S_Date, pos);
        Date sysdate = new Date();
        return idate.after(sysdate);
    }

    public int getDifference(String S_Date1,  String Input1Format, String S_Date2,  String Input2Format)
    throws Exception
    {
        SimpleDateFormat input1Formatter = new SimpleDateFormat(Input1Format);
        SimpleDateFormat input2Formatter = new SimpleDateFormat(Input2Format);
        ParsePosition pos1 = new ParsePosition(0);
        ParsePosition pos2 = new ParsePosition(0);

        Date idate1 = input1Formatter.parse(S_Date1, pos1);
        Date idate2 = input2Formatter.parse(S_Date2, pos2);

        GregorianCalendar gc = new GregorianCalendar();

        Date BigDate;

        int sign = 1;

        if (idate1.after(idate2))
        {
            sign = -1;
            gc.setTime(idate2);
            BigDate = idate1;
        }
        else
        {
            sign = 1;
            gc.setTime(idate1);
            BigDate = idate2;
        }

        int difference = 0;

        while(!gc.getTime().equals(BigDate))
        {
            gc.add(Calendar.DAY_OF_MONTH, 1);
            difference++;
        }

        difference = sign * difference;
        return difference;
    }

    public String getPreviousMonth(String S_Date, String InputFormat, String OutputFormat)
    throws Exception
    {
        GregorianCalendar gc = new GregorianCalendar();

        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));

        gc.add(Calendar.MONTH, -1);

        SimpleDateFormat outputFormatter = new SimpleDateFormat(OutputFormat);
        return outputFormatter.format(gc.getTime());
    }

    public String getNextMonth(String S_Date, String InputFormat, String OutputFormat)
    throws Exception
    {
        GregorianCalendar gc = new GregorianCalendar();

        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));

        gc.add(Calendar.MONTH, 1);

        SimpleDateFormat outputFormatter = new SimpleDateFormat(OutputFormat);
        return outputFormatter.format(gc.getTime());
    }

    public String getPreviousDate(String S_Date, String InputFormat, String OutputFormat)
    throws Exception
    {
        GregorianCalendar gc = new GregorianCalendar();

        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));

        gc.add(Calendar.DAY_OF_MONTH, -1);

        SimpleDateFormat outputFormatter = new SimpleDateFormat(OutputFormat);
        return outputFormatter.format(gc.getTime());
    }

    public String getNextDate(String S_Date, String InputFormat, String OutputFormat)
    throws Exception
    {
        GregorianCalendar gc = new GregorianCalendar();

        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));

        gc.add(Calendar.DAY_OF_MONTH, 1);

        SimpleDateFormat outputFormatter = new SimpleDateFormat(OutputFormat);
        return outputFormatter.format(gc.getTime());
    }

    public String getPreviousYear(String S_Date, String InputFormat, String OutputFormat)
    throws Exception
    {
        GregorianCalendar gc = new GregorianCalendar();

        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));

        gc.add(Calendar.YEAR, -1);

        SimpleDateFormat outputFormatter = new SimpleDateFormat(OutputFormat);
        return outputFormatter.format(gc.getTime());
    }

    public String getNextYear(String S_Date, String InputFormat, String OutputFormat)
    throws Exception
    {
        GregorianCalendar gc = new GregorianCalendar();

        SimpleDateFormat inputFormatter = new SimpleDateFormat(InputFormat);
        ParsePosition pos = new ParsePosition(0);
        gc.setTime(inputFormatter.parse(S_Date, pos));

        gc.add(Calendar.YEAR, 1);

        SimpleDateFormat outputFormatter = new SimpleDateFormat(OutputFormat);
        return outputFormatter.format(gc.getTime());
    }
}
