package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FacultyReportDB {
	java.sql.Connection con;
	Statement st;
	ResultSet rs;
	
	public FacultyReportDB()
	{
		//con=new DBConnection().getDatabaseConnection();
	}
	
	public void loadData(String dept,String fname)
	{
		try {
			con=new DBConnection().getDatabaseConnection();
			
			con.createStatement().executeUpdate("delete from facultyfeedback");
			
			String query="SELECT f.mapid,ceil(sum(a1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(a3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b1)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b2)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b3)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(b4)/(cast((count(f.sno)*10) as decimal))*100),ceil(sum(c1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(c3)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d1)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d2)/(cast((count(f.sno)*5) as decimal))*100),ceil(sum(d3)/(cast((count(f.sno)*5) as decimal))*100),count(f.sno) from feedback f,mapsubjects m,subjects s where m.fid=(select fid from faculty where fname=? and dept=?) and m.mapid=f.mapid and m.sid=s.sid  group by f.mapid";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1, fname);
			ps.setString(2, dept);
			//ps.setString(2, sem1);
			//System.out.println(fname+dept);
			ResultSet rs=ps.executeQuery();
			String insertQuery=new String();
			while(rs.next())
			{
				String mapid=rs.getString(1);
				int a1=rs.getInt(2);
				int a2=rs.getInt(3);
				int a3=rs.getInt(4);
				int b1=rs.getInt(5);
				int b2=rs.getInt(6);
				int b3=rs.getInt(7);
				int b4=rs.getInt(8);
				int c1=rs.getInt(9);
				int c2=rs.getInt(10);
				int c3=rs.getInt(11);
				int d1=rs.getInt(12);
				int d2=rs.getInt(13);
				int d3=rs.getInt(14);
				int a=(int)(Math.ceil((a1+a2+a3)/3));
				int b=(int)(Math.ceil((b1+b2+b3+b4)/4));
				int c=(int)(Math.ceil((c1+c2+c3)/3));
				int d=(int)(Math.ceil((d1+d2+d3)/3));
				int totres=(int)(Math.ceil((a+b+c+d)/4));
				int totst=rs.getInt(15);
				String subquery="select section,s.subname,s.branch,s.year,s.sem,s.ay from mapsubjects m,subjects s where mapid=? and m.sid=s.sid";
				
				PreparedStatement pq=con.prepareStatement(subquery);
				pq.setString(1,mapid);
				ResultSet sub=pq.executeQuery();
				String subname=new String();
				String branch=new String();
				String year=new String();
				String sem=new String();
				String section=new String();
				String ay=new String();
				
				
				if(sub.next())
				{
					 subname=sub.getString(2);
					 branch=sub.getString(3);
					 year=sub.getString(4);
					 sem=sub.getString(5);
					 section=sub.getString(1);
					ay=sub.getString(6);
						
				}
				
				//System.out.println(branch+year+section+" "+sem);
				String totqry="select count(*) from students where branch=? and syear=? and sem=? and section=?";
				PreparedStatement totp =con.prepareStatement(totqry);
				totp.setString(1, branch);
				totp.setString(2, year);
				totp.setString(3, sem);
				totp.setString(4, section);
				ResultSet totr=totp.executeQuery();
				
				int sttotal=0;
				if(totr.next())
					sttotal=totr.getInt(1);
				String totop=totst+" / "+sttotal;
                 				
				//System.out.println(sttotal);
				
				String cls=year+" B.TECH - "+sem+" SEM";
				String brch=branch+" - "+section;
				insertQuery="insert into facultyfeedback values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
				
				PreparedStatement iq=con.prepareStatement(insertQuery);
				
				iq.setString(1, cls);
				iq.setString(2, subname);
				iq.setString(3, brch);
				iq.setInt(4, a1);
				iq.setInt(5, a2);
				iq.setInt(6, a3);
				iq.setInt(7, b1);
				iq.setInt(8, b2);
				iq.setInt(9, b3);
				iq.setInt(10, b4);
				iq.setInt(11, c1);
				iq.setInt(12, c2);
				iq.setInt(13, c3);
				iq.setInt(14, d1);
				iq.setInt(15, d2);
				iq.setInt(16, d3);
				iq.setInt(17, a);
				iq.setInt(18, b);
				iq.setInt(19, c);
				iq.setInt(20, d);
				iq.setInt(21, totres);
				iq.setString(22, totop);
				iq.setString(23, ay);
				iq.setString(24, getDeptName(dept));
				iq.setString(25,fname);
				iq.executeUpdate();
				
			}
							
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
	}
	public String getDeptName(String dept)
	{
	   if(dept.equals("I.T"))
		   return "Information Technology(IT)";
		   else if(dept.equals("C.S.E"))
			   return "Computer Science(CSE)";
		   else if(dept.equals("E.C.E"))
			   return "Electronics and Communications(ECE)";
		   else if(dept.equals("E.E.E"))
			   return "Electrical and Electronics(EEE)";
		   else if(dept.equals("MECH"))
			   return "Mechanical";
		   else if(dept.equals("CIVIL"))
			   return "Civil";
		   else if(dept.equals("M.C.A"))
			   return "MCA";
		   else if(dept.equals("M.B.A"))
			   return "MBA";
		   else if(dept.equals("Basic Science"))
			   return "Basic Science(BS)";
	   return "";
	    }

}
