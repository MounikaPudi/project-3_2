package dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class AggregateReportData {
	java.sql.Connection con;
	Statement st;
	ResultSet rs;
	private String acayear;
	
	public AggregateReportData()
	{
	//	con=new DBConnection().getDatabaseConnection();
	}
	public Vector loadData()
	{
		con=new DBConnection().getDatabaseConnection();
		Vector data=new Vector();
		Vector titles=new Vector();
		try {
			st=con.createStatement();
			String query="select class,branch,ay,subjname,tot,fname,dept from facultyfeedback";
			rs=st.executeQuery(query);
			int i=0;
			while(rs.next())
			{
				Vector row=new Vector();
				if(i==0)
				{
					titles.add(rs.getString(1));
					titles.add(rs.getString(2));
					titles.add(rs.getString(3));
					data.add(titles);
					i++;
				}
				row.add(rs.getString(4));
				row.add(rs.getString(5));
				row.add(rs.getString(6));
				row.add(rs.getString(7));
				data.add(row);
			}
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  new DBConnection().releaseDatabaseConnection(con);
  return data;
	}
}
