package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

public class MapSubjectDB {
	java.sql.Connection con;
	Statement st;
	ResultSet rs;

	public MapSubjectDB()
	{
		//con=new DBConnection().getDatabaseConnection();
	}
	public boolean insertMapping(MapSubject ms)
	{
		String query="insert into mapsubjects values(?,?,?,?,?)";
		PreparedStatement psmt;
		try {
			con=new DBConnection().getDatabaseConnection();
			psmt = con.prepareStatement(query);
			//System.out.println(ms.getMapid());
			psmt.setString(1,ms.getMapid());
			psmt.setString(2,ms.getFid());
			psmt.setString(3,ms.getSubjid());
			psmt.setString(4,ms.getSec());
			psmt.setString(5,ms.getAy());
			
			int cnt=psmt.executeUpdate();
			new DBConnection().releaseDatabaseConnection(con);
			if(cnt>0)
			{
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return  false;
	
	}
	public boolean deleteMapping(String subjid,String sec)
	{
		String query="delete from mapsubjects where sid=? and section=?";
		
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement listquery=con.prepareStatement(query);
			listquery.setString(1, subjid);
			listquery.setString(2, sec);
			int rs=listquery.executeUpdate();
			new DBConnection().releaseDatabaseConnection(con);
			if(rs>0)
			{
			    return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}

	public Vector loadMappedSubjectsList(String branch,String year,String sem,String ay,String sec)
	 {
		
		String query="select sid,subname from subjects s where branch=? and year=? and sem=? and ay=? AND EXISTS (SELECT * FROM MAPSUBJECTS WHERE SID=s.sid and section=?)";
		
		Vector slist=new Vector();
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement listquery=con.prepareStatement(query);
			listquery.setString(1, branch);
			listquery.setString(2, year);
			listquery.setString(3, sem);
			listquery.setString(4, ay);
			listquery.setString(5, sec);
			rs=listquery.executeQuery();
			while(rs.next())
			{
				Vector subject=new Vector();
				subject.addElement(rs.getString(1));
				subject.addElement(rs.getString(2));
				slist.addElement(subject);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return slist;
	 }

	public String loadMappedFaculty(String subj,String sec)
	{
      String query="select fid from mapsubjects where sid=? and section=?";
		
		String fid=new String();
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement listquery=con.prepareStatement(query);
			listquery.setString(1, subj);
			listquery.setString(2, sec);
			rs=listquery.executeQuery();
			if(rs.next())
			{
				fid=rs.getString(1);
			}
			new DBConnection().releaseDatabaseConnection(con);
			return fid;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public Vector loadSubjectsList(String branch,String year,String sem,String ay,String sec)
	 {
		
		String query="select sid,subname from subjects s where branch=? and year=? and sem=? and ay=? AND NOT EXISTS (SELECT * FROM MAPSUBJECTS WHERE SID=s.sid and section=?)";
		
		Vector slist=new Vector();
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement listquery=con.prepareStatement(query);
			listquery.setString(1, branch);
			listquery.setString(2, year);
			listquery.setString(3, sem);
			listquery.setString(4, ay);
			listquery.setString(5, sec);
			rs=listquery.executeQuery();
			while(rs.next())
			{
				Vector subject=new Vector();
				subject.addElement(rs.getString(1));
				subject.addElement(rs.getString(2));
				slist.addElement(subject);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return slist;
	 }
	public boolean insertFEMapping(MapSubject ms) {
		// TODO Auto-generated method stub
		String query="insert into femap values(?,?,?,?)";
		PreparedStatement psmt;
		try {
			con=new DBConnection().getDatabaseConnection();
			psmt = con.prepareStatement(query);
			//System.out.println(ms.getMapid());
			psmt.setString(1,ms.getMapid());
			psmt.setString(3,ms.getFid());
			psmt.setString(2,ms.getSubjid());
			
			psmt.setString(4,ms.getAy());
			
			int cnt=psmt.executeUpdate();
			new DBConnection().releaseDatabaseConnection(con);
			if(cnt>0)
			{
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return  false;
			
	}
	public boolean insertOEMapping(MapSubject ms) {
		// TODO Auto-generated method stub
		String query="insert into oemap values(?,?,?,?,?)";
		PreparedStatement psmt;
		try {
			con=new DBConnection().getDatabaseConnection();
			psmt = con.prepareStatement(query);
			//System.out.println(ms.getMapid());
			psmt.setString(1,ms.getMapid());
			psmt.setString(3,ms.getFid());
			psmt.setString(2,ms.getSubjid());
			psmt.setString(4,ms.getAy());
			psmt.setString(5, ms.getBranch());
			
			int cnt=psmt.executeUpdate();
			new DBConnection().releaseDatabaseConnection(con);
			if(cnt>0)
			{
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return  false;
			
	}
	public ArrayList getOESubjects(String branch)
	 {
		
		String query="select * from oemap where branch=?";
		
		ArrayList slist=new ArrayList();
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement listquery=con.prepareStatement(query);
			listquery.setString(1, branch);
			rs=listquery.executeQuery();
			while(rs.next())
			{
			String mapid=rs.getString(1);
			String sid=rs.getString(2);
			String fid=rs.getString(3);
			String ay=rs.getString(4);
			MapSubject ms=new MapSubject();
			ms.setMapid(mapid);
			ms.setFid(fid);
			ms.setSubjid(sid);
			ms.setAy(ay);
			ms.setSubname(new SubjectDB().getOESubjectName(sid));
			slist.add(ms);
			
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return slist;
	 }
}
