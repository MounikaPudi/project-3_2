package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class FeedBackDB {
	
	
	Statement st;
	ResultSet rs;

	public FeedBackDB()
	{
		//con=new DBConnection().getDatabaseConnection();
	}


	public int insertFeedbackEntries(Vector feedback) {
		// TODO Auto-generated method stub
		String query="insert into feedback values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		int totcnt=0;
		Connection con=null;
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement psmt=con.prepareStatement(query);
			for(int i=0;i<feedback.size();i++)
			{
				Vector entry=(Vector)feedback.elementAt(i);
				
				    	String fdid=(String)entry.elementAt(0);
				    	String mapid=(String)entry.elementAt(1);
				    	String stno=(String)entry.elementAt(2);
				    	//System.out.println("in database:"+stno);
				    	
				    	int a1=Integer.parseInt(entry.elementAt(3).toString());
				    	int a2=Integer.parseInt(entry.elementAt(4).toString());
				    	int a3=Integer.parseInt(entry.elementAt(5).toString());
				    	int b1=Integer.parseInt(entry.elementAt(6).toString());
				    	int b2=Integer.parseInt(entry.elementAt(7).toString());
				    	int b3=Integer.parseInt(entry.elementAt(8).toString());
				    	int b4=Integer.parseInt(entry.elementAt(9).toString());
				    	int c1=Integer.parseInt(entry.elementAt(10).toString());
				    	int c2=Integer.parseInt(entry.elementAt(11).toString());
				    	int c3=Integer.parseInt(entry.elementAt(12).toString());
				    	int d1=Integer.parseInt(entry.elementAt(13).toString());
				    	int d2=Integer.parseInt(entry.elementAt(14).toString());
				    	int d3=Integer.parseInt(entry.elementAt(15).toString());
				    	
				    	int ta=((Integer)entry.elementAt(16)).intValue();
				    	int tb=((Integer)entry.elementAt(17)).intValue();
				    	int tc=((Integer)entry.elementAt(18)).intValue();
				    	int td=((Integer)entry.elementAt(19)).intValue();
				    	int tot=((Integer)entry.elementAt(20)).intValue();
				    	
				    	psmt.setString(1,fdid);
				    	psmt.setString(2,mapid);
				    	psmt.setString(3,stno);
				    	psmt.setInt(4, a1);
				    	psmt.setInt(5, a2);
				    	psmt.setInt(6, a3);
				    	psmt.setInt(7, b1);
				    	psmt.setInt(8, b2);
				    	psmt.setInt(9, b3);
				    	psmt.setInt(10, b4);
				    	psmt.setInt(11, c1);
				    	psmt.setInt(12, c2);
				    	psmt.setInt(13, c3);
				    	psmt.setInt(14, d1);
				    	psmt.setInt(15, d2);
				    	psmt.setInt(16, d3);
				    	psmt.setInt(17, ta);
				    	psmt.setInt(18, tb);
				    	psmt.setInt(19, tc);
				    	psmt.setInt(20, td);
				    	psmt.setInt(21, tot);
				    	int cnt=psmt.executeUpdate();
				    	if(cnt>0)
				    	  totcnt++;
			}
				
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return totcnt;
		
	}
	public boolean checkForFdbEntry(UserRecord ur)
	{
	   String query="select count(*) from feedback group by sno having sno=? ";
	   Connection con=null;
	   try {
		   con=new DBConnection().getDatabaseConnection();
		   
		   PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1, ur.getLoginid());
		   ResultSet rs=ps.executeQuery();
		   if(rs.next())
		   {
			   int cnt=rs.getInt(1);
			   if(cnt>0)
				   return false;
			}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	new DBConnection().releaseDatabaseConnection(con);
	return true;
	}


	public void loadAttemptedList(String branch, String year, String sem,String sec) 
	{
     String query="select sno,sname from students s where branch=? and section=? and syear=? and sem=? and exists (select sno from feedback group by sno having sno=s.sno)order by sno";
     String insert="insert into attemptedstlist values(?,?)";
     Connection con=null;
     try {
    	 con=new DBConnection().getDatabaseConnection();
    	 con.createStatement().executeUpdate("delete from attemptedstlist");
		PreparedStatement ps=con.prepareStatement(query);
		 PreparedStatement ips=con.prepareStatement(insert);
		 
		 ps.setString(1, branch);
		 ps.setString(2, sec);
		 ps.setString(3, year);
		 ps.setString(4, sem);
		 
		 ResultSet list=ps.executeQuery();
		 while(list.next())
		 {
			 ips.setString(1, list.getString(1));
			 ips.setString(2, list.getString(2));
			 ips.executeUpdate();
		 }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    	 new DBConnection().releaseDatabaseConnection(con);
    }


	public void loadNotAttemptedList(String branch, String year, String sem,String sec) 
	{
		 String query="select sno,sname from students s where branch=? and section=? and syear=? and sem=? and not exists (select sno from feedback group by sno having sno=s.sno) order by sno";
	     String insert="insert into notattemptstlist values(?,?)";
	     Connection con=null;
	     try {
	    	 con=new DBConnection().getDatabaseConnection();
		     con.createStatement().executeUpdate("delete from notattemptstlist");
	    	 PreparedStatement ps=con.prepareStatement(query);
			 PreparedStatement ips=con.prepareStatement(insert);
			 
			 ps.setString(1, branch);
			 ps.setString(2, sec);
			 ps.setString(3, year);
			 ps.setString(4, sem);
			 
			 ResultSet list=ps.executeQuery();
			 while(list.next())
			 {
				 ips.setString(1, list.getString(1));
				 ips.setString(2, list.getString(2));
				 ips.executeUpdate();
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
	    	 
	}
	Vector getList(String type)
	{
		String query;
		Vector list=new Vector();
		Connection con=null;
		try {
			con=new DBConnection().getDatabaseConnection();
			if (type.equals("attempt")) {
				query = "select * from attemptedstlist order by sno";
				ResultSet rs = con.createStatement().executeQuery(query);
				while (rs.next()) {
					Student st = new Student();
					st.setSno(rs.getString(1));
					st.setSname(rs.getString(2));
					list.add(st);
				}

			} else if (type.equals("not attempt")) {
				query = "select * from notattemptstlist order by sno";
				ResultSet rs = con.createStatement().executeQuery(query);
				while (rs.next()) {
					Student st = new Student();
					st.setSno(rs.getString(1));
					st.setSname(rs.getString(2));
					list.add(st);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		new DBConnection().releaseDatabaseConnection(con);
		return list;
	}


	public boolean checkForFEEntry(UserRecord ur) {
		// TODO Auto-generated method stub
		
		
		String query="select * from feedback where left(mapid,8) in('UGCS2T03','UGCE2T01','UGEC2T01','UGEE2T01','UGME2T02') and sno=? ";
		Connection con=null;
		   try {
			   con=new DBConnection().getDatabaseConnection();
			   
			   PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, ur.getLoginid());
			   ResultSet rs=ps.executeQuery();
			   if(rs.next())
			   {
					   return false;
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return true;

	}
	public boolean checkForOEEntry(String sno,String subid,String fno) {
		// TODO Auto-generated method stub
		
		String fdid=subid+"-"+fno+"-"+sno;
		String query="select * from feedback where fdid=? ";
		Connection con=null;
		   try {
			   con=new DBConnection().getDatabaseConnection();
			   
			   PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, fdid);
			   ResultSet rs=ps.executeQuery();
			   if(rs.next())
			   {
				   new DBConnection().releaseDatabaseConnection(con);
				   return true;
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return false;

	}

	public boolean checkForMBAElEntry(UserRecord ur) {
		// TODO Auto-generated method stub
		
		
		String query="select * from feedback where left(mapid,8) in('PGMB3T06','PGMB3T07','PGMB3T08','PGMB3T09') and sno=? ";
		Connection con=null;
		   try {
			   con=new DBConnection().getDatabaseConnection();
			   
			   PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, ur.getLoginid());
			   ResultSet rs=ps.executeQuery();
			   if(rs.next())
			   {
					   return false;
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return true;

	}


	public int deleteOEfeedback() {
		// TODO Auto-generated method stub
		
		String query="delete from feedback where mapid in(select mapid from oemap) ";
		String query1="delete from oemap ";
		int cnt=0;
		Connection con=null;
		   try {
			   con=new DBConnection().getDatabaseConnection();
			   
			 cnt=con.createStatement().executeUpdate(query);
			con.createStatement().execute(query1);
			   
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return cnt;


	}


	public int deleteFeedback() {
		// TODO Auto-generated method stub

		String query1="delete from feedback";
		int cnt=1;
		Connection con=null;
		   try {
			   con=new DBConnection().getDatabaseConnection();
			   con.createStatement().execute(query1);
			   
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return cnt;


	}
}
