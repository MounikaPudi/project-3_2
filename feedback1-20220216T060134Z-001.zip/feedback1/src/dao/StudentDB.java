package dao;

import java.io.FileInputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class StudentDB {
	
	java.sql.Connection con;
	Statement st;
	ResultSet rs;

	public StudentDB()
	{
//		con=new DBConnection().getDatabaseConnection();
	}
	
	public boolean insertStudent(Student newst) throws SQLException
	{
		String query="insert into students values(?,?,?,?,?,?)";
		String lquery="insert into users values(?,?,?,?)";
		con=new DBConnection().getDatabaseConnection();
		
		PreparedStatement psmt=con.prepareStatement(query);
		PreparedStatement user=con.prepareStatement(lquery);
		
		psmt.setString(1,newst.getSno());
		psmt.setString(2,newst.getSname());
		psmt.setString(3,newst.getBranch());
		psmt.setString(4,newst.getSection());
		psmt.setString(5,newst.getYear());
		psmt.setString(6,newst.getSem());
		int cnt=psmt.executeUpdate();
		
		user.setString(1,newst.getSno());
		user.setString(2,newst.getSno());
		user.setString(3,"student");
		user.setInt(4,1);
		int ucnt=user.executeUpdate();
		
		new DBConnection().releaseDatabaseConnection(con);
		if(cnt>0&&ucnt>0)
		{
			return true;
		}
		return  false;
		
	}
	public int uploadStudents(String file)
	{
		 //fileName="E:\\EXAS\\stlist.xls";
        //Read an Excel File and Store in a Vector
        Vector dataHolder=readExcelFile(file);
        //Print the data read
        try {
			int cnt=printCellDataToConsole(dataHolder);
			if(cnt>0)
				return cnt;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}
	
	 public Vector readExcelFile(String fileName)
	    {
	        /** --Define a Vector
	            --Holds Vectors Of Cells
	         */
	        Vector cellVectorHolder = new Vector();

	        try{
	        /** Creating Input Stream**/
	        //InputStream myInput= ReadExcelFile.class.getResourceAsStream( fileName );
	        FileInputStream myInput = new FileInputStream(fileName);

	        /** Create a POIFSFileSystem object**/
	        POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

	        /** Create a workbook using the File System**/
	         HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

	         /** Get the first sheet from workbook**/
	        HSSFSheet mySheet = myWorkBook.getSheetAt(0);

	        /** We now need something to iterate through the cells.**/
	          Iterator rowIter = mySheet.rowIterator();

	          while(rowIter.hasNext()){
	              HSSFRow myRow = (HSSFRow) rowIter.next();
	              Iterator cellIter = myRow.cellIterator();
	              Vector cellStoreVector=new Vector();
	              while(cellIter.hasNext()){
	                  HSSFCell myCell = (HSSFCell) cellIter.next();
	                  cellStoreVector.addElement(myCell);
	              }
	              cellVectorHolder.addElement(cellStoreVector);
	          }
	        }catch (Exception e){e.printStackTrace(); }
	        return cellVectorHolder;
	    }
	 
	 private int printCellDataToConsole(Vector dataHolder) throws SQLException {
		 String query="insert into students values(?,?,?,?,?,?)";
		 String lquery="insert into users values(?,?,?,?)";
		 String rno=new String();
		 
		 con=new DBConnection().getDatabaseConnection();
			PreparedStatement ps=con.prepareStatement(query);
			PreparedStatement user=con.prepareStatement(lquery);
			int cnt=0;
      
	        for (int i=0;i<dataHolder.size(); i++){
	                   Vector cellStoreVector=(Vector)dataHolder.elementAt(i);
	            for (int j=0; j < cellStoreVector.size();j++){
	                HSSFCell myCell = (HSSFCell)cellStoreVector.elementAt(j);
	                String stringCellValue = myCell.toString();
	                if(j==0)
	                	rno=myCell.toString();
	                try {
	                    ps.setString(j + 1, stringCellValue);
	                } catch (SQLException ex) {
	                    Logger.getLogger(StudentDB.class.getName()).log(Level.SEVERE, null, ex);
	                }
	               // System.out.print(stringCellValue+"\t");
	            }
	            try {
	            	user.setString(1,rno);
	        		user.setString(2,rno);
	        		user.setString(3,"student");
	        		user.setInt(4,1);
	        		user.executeUpdate();
	        		ps.executeUpdate();
	                
	                cnt++;
	            } catch (SQLException ex) {
	                Logger.getLogger(StudentDB.class.getName()).log(Level.SEVERE, null, ex);
	            }
	           // System.out.println();
	        }
	        new DBConnection().releaseDatabaseConnection(con);
	        return cnt;
	    }
	 
	 public int deleteStudentInfo(String sno)
	 {
		 String query="delete from students where sno=?";
		 String lquery="delete from users where id=?";
			
			try {
				con=new DBConnection().getDatabaseConnection();
				PreparedStatement st=con.prepareStatement(query);
				PreparedStatement lt=con.prepareStatement(lquery);
				
				lt.setString(1, sno);
				st.setString(1, sno);
				int lr=lt.executeUpdate();
				int sr=st.executeUpdate();
				
				new DBConnection().releaseDatabaseConnection(con);
				if(lr>0 && sr>0)
				  return sr;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 0;
			}
			return 0;
		 
	 }
	 
	 public int deleteStudentYearwise(String year,String branch)
	 {
		 String query=new String();
		 String lquery=new String();
		 if(branch.equals("all"))
		 {
			query="delete from students where syear=?";
			lquery="delete from users where id in (select sno from students where syear=?)";
		 }
		 else
		 {
			 query="delete from students where syear=? and branch=?";
			 lquery="delete from users where id in (select sno from students where syear=? and branch=?)";
		 }
		 
		 
			
			try {
				con=new DBConnection().getDatabaseConnection();
				PreparedStatement st=con.prepareStatement(query);
				PreparedStatement lt=con.prepareStatement(lquery);
				
				lt.setString(1, year);
				st.setString(1, year);
				
				if(!branch.equals("all"))
				{
					st.setString(2, branch);
					lt.setString(2, branch);
				}
				
				
				
				
				
				int lr=lt.executeUpdate();
				int sr=st.executeUpdate();
				
				new DBConnection().releaseDatabaseConnection(con);
				if(lr>0 && sr>0)
				  return sr;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 0;
			}
			return 0;
		 
		 
	 }
	 public int classDeletion(String branch,String year,String sem,String sec)
	 {
		 String query=new String();
		 String lquery=new String();
		 
			query="delete from students where syear=? and branch=? and sem=? and section=?";
			lquery="delete from users where id in (select sno from students where syear=? and branch=? and sem=? and section=?)";
		
		 
		 
			
			try {
				con=new DBConnection().getDatabaseConnection();
				PreparedStatement st=con.prepareStatement(query);
				PreparedStatement lt=con.prepareStatement(lquery);
				
				
				st.setString(1, year);
				st.setString(2, branch);
				st.setString(3, sem);
				st.setString(4, sec);
				
				lt.setString(1, year);
				lt.setString(2, branch);
				lt.setString(3, sem);
				lt.setString(4, sec);
				
				
				
				
				
				int lr=lt.executeUpdate();
				int sr=st.executeUpdate();
				
				new DBConnection().releaseDatabaseConnection(con);
				if(lr>0 && sr>0)
				  return sr;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 0;
			}
			return 0;
		 
	 }
	 public int promotions(String branch,String year,String demotelist)
	 {
		 String query=new String();
		
			try {
				con=new DBConnection().getDatabaseConnection();
				ResultSet rs=con.createStatement().executeQuery("select sem from students where syear='"+year+"' and branch='"+branch+"' group by sem");
				String sem=new String();
				if(rs.next())
					sem=rs.getString(1);
				
				PreparedStatement st;
				
				
				if(sem.equals("I"))
				{
					if(!demotelist.equals(""))
					 {
						StringTokenizer dlist=new StringTokenizer(demotelist,",");
						String inp=new String();
						while(dlist.hasMoreTokens())
						{
							inp=inp+"'"+dlist.nextToken()+"',";
						}
						inp=inp.substring(0, inp.lastIndexOf(","));

						query="update students set syear=? , sem=? where syear=? and branch=? and sno not in("+inp+")";

						st=con.prepareStatement(query);
						st.setString(1,year);
						st.setString(2,"II");
						st.setString(3, year);
						st.setString(4, branch);
						
						
					 }
					 else
					 {
						 query="update students set syear=? , sem=? where syear=? and branch=?";
						 st=con.prepareStatement(query);
							st.setString(1,year);
							st.setString(2,"II");
							st.setString(3, year);
							st.setString(4, branch);
					 }
					int cnt=st.executeUpdate();
					return cnt;

 	
				}
				else if(sem.equals("II"))
				{
					if(!demotelist.equals(""))
					 {
						
						StringTokenizer dlist=new StringTokenizer(demotelist,",");
						String inp=new String();
						while(dlist.hasMoreTokens())
						{
							inp=inp+"'"+dlist.nextToken()+"',";
						}
						inp=inp.substring(0, inp.lastIndexOf(","));

						query="update students set syear=? , sem=? where syear=? and branch=? and sno not in("+inp+")";
						
						st=con.prepareStatement(query);
						st.setString(1,getNextYear(year));
						st.setString(2,"I");
						st.setString(3, year);
						st.setString(4, branch);
						
						

					 }
					 else
					 {
						 query="update students set syear=? , sem=? where syear=? and branch=?";
						 st=con.prepareStatement(query);
							st.setString(1,getNextYear(year));
							st.setString(2,"I");
							st.setString(3, year);
							st.setString(4, branch);
							System.out.println("without demote list");


					 }
					int cnt=st.executeUpdate();
					return cnt;

				}
				new DBConnection().releaseDatabaseConnection(con);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 0;
			}
			return 0;
		
	 }
	 private String getNextYear(String year)
	 {
		 if(year.equals("I"))
			 return "II";
		 else if(year.equals("II"))
			 return "III";
		 if(year.equals("III"))
			 return "IV";
		 return null;
			 
	 }
	 
	 public boolean updateStudent(Student st) throws SQLException
	 {
		 String query="update students set sname=?, branch=?, section=?, syear=?, sem=? where sno=?";
			con=new DBConnection().getDatabaseConnection();
			
			PreparedStatement psmt=con.prepareStatement(query);

			
			psmt.setString(6,st.getSno());
			psmt.setString(1,st.getSname());
			psmt.setString(2,st.getBranch());
			psmt.setString(3,st.getSection());
			psmt.setString(4,st.getYear());
			psmt.setString(5,st.getSem());
			int cnt=psmt.executeUpdate();
			
			
			new DBConnection().releaseDatabaseConnection(con);
			if(cnt>0)
			{
				return true;
			}
			return  false;
		
		 
	 }

	public int doPromotions(String fromyear, String fromsem, String toyear,
			String tosem) {
		// TODO Auto-generated method stub
		int cnt=0;
		 try {
			String query="update students set SET SYEAR=? , SEM=? WHERE SYEAR=? AND SEM=?";
				con=new DBConnection().getDatabaseConnection();
				
				PreparedStatement psmt=con.prepareStatement(query);

				
				
				psmt.setString(1,toyear);
				psmt.setString(2,tosem);
				psmt.setString(3,fromyear);
				psmt.setString(4,fromsem);
				
			 cnt=psmt.executeUpdate();
				
				
				new DBConnection().releaseDatabaseConnection(con);
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return cnt;
	}

}
