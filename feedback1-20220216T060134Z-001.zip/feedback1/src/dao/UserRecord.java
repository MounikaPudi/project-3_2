package dao;

public class UserRecord {
private String loginid;
private String pwd;
private String type;
private int active;

public String getLoginid() {
	return loginid;
}
public void setLoginid(String loginid) {
	this.loginid = loginid;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public int getActive() {
	return active;
}
public void setActive(int active) {
	this.active = active;
}


}
