package dao;

import java.util.Hashtable;
import java.util.Vector;

public class StudentData {
Student stdnt;
Vector subjects;

public Vector getSubjects() {
	return subjects;
}
public void setSubjects(Vector subjects) {
	this.subjects = subjects;
}
public Student getStdnt() {
	return stdnt;
}
public void setStdnt(Student stdnt) {
	this.stdnt = stdnt;
}

}
