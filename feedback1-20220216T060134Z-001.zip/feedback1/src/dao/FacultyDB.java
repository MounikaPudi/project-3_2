package dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class FacultyDB {
	
	java.sql.Connection con;
	Statement st;
	ResultSet rs;
	
	public FacultyDB()
	{
		//con=new DBConnection().getDatabaseConnection();
	}
	public boolean insertFaculty(Faculty newft) throws SQLException
	{
		String query="insert into faculty values(?,?,?)";
		String lquery="insert into users values(?,?,?,?)";
		
		con=new DBConnection().getDatabaseConnection();
		PreparedStatement psmt=con.prepareStatement(query);
		PreparedStatement lpsmt=con.prepareStatement(lquery);
		
		
		psmt.setString(1,newft.getFid());
		psmt.setString(2,newft.getFname());
		psmt.setString(3,newft.getDept());
		
		lpsmt.setString(1,newft.getFid());
		lpsmt.setString(2,"1234");
		lpsmt.setString(3,"faculty");
		lpsmt.setInt(4,1);
		
			int cnt=psmt.executeUpdate();
			int lcnt=lpsmt.executeUpdate();
		if(cnt>0&&lcnt>0)
		{
			new DBConnection().releaseDatabaseConnection(con);
			return true;
		}
		new DBConnection().releaseDatabaseConnection(con);
		return  false;
		
	}
	public int uploadFaculty(String file)
	{
		 //fileName="E:\\EXAS\\stlist.xls";
        //Read an Excel File and Store in a Vector
        Vector dataHolder=readExcelFile(file);
        //Print the data read
        try {
			int cnt=printCellDataToConsole(dataHolder);
			if(cnt>0)
				return cnt;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}
	
	 public Vector readExcelFile(String fileName)
	    {
	        /** --Define a Vector
	            --Holds Vectors Of Cells
	         */
	        Vector cellVectorHolder = new Vector();

	        try{
	        /** Creating Input Stream**/
	        //InputStream myInput= ReadExcelFile.class.getResourceAsStream( fileName );
	        FileInputStream myInput = new FileInputStream(fileName);

	        /** Create a POIFSFileSystem object**/
	        POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

	        /** Create a workbook using the File System**/
	         HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

	         /** Get the first sheet from workbook**/
	        HSSFSheet mySheet = myWorkBook.getSheetAt(0);

	        /** We now need something to iterate through the cells.**/
	          Iterator rowIter = mySheet.rowIterator();

	          while(rowIter.hasNext()){
	              HSSFRow myRow = (HSSFRow) rowIter.next();
	              Iterator cellIter = myRow.cellIterator();
	              Vector cellStoreVector=new Vector();
	              while(cellIter.hasNext()){
	                  HSSFCell myCell = (HSSFCell) cellIter.next();
	                  cellStoreVector.addElement(myCell);
	              }
	              cellVectorHolder.addElement(cellStoreVector);
	          }
	        }catch (Exception e){e.printStackTrace(); }
	        return cellVectorHolder;
	    }
	 
	 private int printCellDataToConsole(Vector dataHolder) throws SQLException {
		 String query="insert into faculty values(?,?,?)";
		 String lquery="insert into users values(?,?,?,?)";
		 
		 con=new DBConnection().getDatabaseConnection();
			
		 PreparedStatement ps=con.prepareStatement(query);
		 PreparedStatement lpsmt=con.prepareStatement(lquery);
			String fid=new String();
			int cnt=0;

	        for (int i=0;i<dataHolder.size(); i++){
	                   Vector cellStoreVector=(Vector)dataHolder.elementAt(i);
	            for (int j=0; j < cellStoreVector.size();j++){
	                HSSFCell myCell = (HSSFCell)cellStoreVector.elementAt(j);
	                String stringCellValue = myCell.toString();
	                try {
	                	
	                	//System.out.println(stringCellValue);
	                	if(j==0)
	                	{
	                	    try
	                	    {
	                		fid=stringCellValue.substring(0,stringCellValue.indexOf('.'));
	                	    ps.setString(j + 1, fid);
	                	    }
	                	    catch(StringIndexOutOfBoundsException si)
	                	    {
	                	    	fid=stringCellValue;
	                	    	ps.setString(j + 1, stringCellValue);	
	                	    }
	                	}
	                	else
	                       	ps.setString(j + 1, stringCellValue);
	                } catch (SQLException ex) {
	                    Logger.getLogger(StudentDB.class.getName()).log(Level.SEVERE, null, ex);
	                }
	               // System.out.print(stringCellValue+"\t");
	            }
	            try {
	            	lpsmt.setString(1,fid);
	        		lpsmt.setString(2,fid);
	        		lpsmt.setString(3,"faculty");
	        		lpsmt.setInt(4,1);
	        		
	            	ps.executeUpdate();
	            	lpsmt.executeUpdate();
	                cnt++;
	            } catch (SQLException ex) {
	                Logger.getLogger(StudentDB.class.getName()).log(Level.SEVERE, null, ex);
	            }
	           // System.out.println();
	        }
	        new DBConnection().releaseDatabaseConnection(con);
	        return cnt;
	    }
	 public Vector loadFacultyList(String dept)
	 {
		 String query="select fid,fname from faculty where dept=?";
			Vector flist=new Vector();
			try {
				con=new DBConnection().getDatabaseConnection();
				
				PreparedStatement listquery=con.prepareStatement(query);
				listquery.setString(1, dept);
				rs=listquery.executeQuery();
				while(rs.next())
				{
					Vector faculty=new Vector();
					faculty.addElement(rs.getString(1));
					faculty.addElement(rs.getString(2));
					flist.addElement(faculty);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			new DBConnection().releaseDatabaseConnection(con);
			return flist;
		 
		 
	 }
	 public String getFacultyName(String fid)
	 {
		 String query="select fname from faculty where fid=?";
			String fname=new String();
			try {
				
				con=new DBConnection().getDatabaseConnection();
				
				PreparedStatement listquery=con.prepareStatement(query);
				listquery.setString(1, fid);
				rs=listquery.executeQuery();
				//System.out.println(fid);
				if(rs.next())
				{
				  fname=rs.getString(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			new DBConnection().releaseDatabaseConnection(con);
			return fname;
		 
	 }
	 public Hashtable getAllFacultyNames(String dept)
	 {
		 String query="select fid,fname from faculty where dept=? order by fid ";
		 PreparedStatement fq;
		 Hashtable ftable=new Hashtable();
		try {
			con=new DBConnection().getDatabaseConnection();
			fq = con.prepareStatement(query);
			fq.setString(1, dept);
			ResultSet flist=fq.executeQuery();
			
			while(flist.next())
			{
				String fid=flist.getString(1);
				//System.out.println(fid);
				String fname=flist.getString(2);
				ftable.put(fid,fname);
			
				//System.out.println(ftable);
				
			}
						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
//		System.out.println(ftable);
		return ftable;
		 
		 
	 }

	 public String getFacultyDept(String fid)
	 {
		 String query="select dept from faculty where fid=?";
			String dept=new String();
			try {
				con=new DBConnection().getDatabaseConnection();
				PreparedStatement listquery=con.prepareStatement(query);
				listquery.setString(1, fid);
				rs=listquery.executeQuery();
				//System.out.println(fid);
				if(rs.next())
				{
				  dept=rs.getString(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			new DBConnection().releaseDatabaseConnection(con);
			return dept;
		 
	 }
	 public int deleteFacultyInfo(String fno)
	 {
		 String query="delete from faculty where fid=?";
		 String lquery="delete from users where id=?";
			
			try {
				con=new DBConnection().getDatabaseConnection();
				
				PreparedStatement st=con.prepareStatement(query);
				PreparedStatement lt=con.prepareStatement(lquery);
				
				lt.setString(1, fno);
				st.setString(1, fno);
				int lr=lt.executeUpdate();
				int sr=st.executeUpdate();
				
				
				if(lr>0 && sr>0)
				  return sr;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return 0;
			}
			new DBConnection().releaseDatabaseConnection(con);
			return 0;
		
	 }
	public Vector loadFEFacultyList(String fe) {
		// TODO Auto-generated method stub
		String query="select m.fid,f.fname from femap m,faculty f where m.fid=f.fid and sid=? ";
		Vector flist=new Vector();
		try {
			con=new DBConnection().getDatabaseConnection();
			
			PreparedStatement listquery=con.prepareStatement(query);
			listquery.setString(1, fe);
			rs=listquery.executeQuery();
			while(rs.next())
			{
				Vector faculty=new Vector();
				faculty.addElement(rs.getString(1));
				faculty.addElement(rs.getString(2));
				flist.addElement(faculty);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		new DBConnection().releaseDatabaseConnection(con);
		return flist;
	
	}
	public Vector loadOEFacultyList(String fe,String branch) {
		// TODO Auto-generated method stub
		String query="select m.fid,f.fname from oemap m,faculty f where m.fid=f.fid and sid=? and m.branch=? ";
		Vector flist=new Vector();
		try {
			con=new DBConnection().getDatabaseConnection();
			
			PreparedStatement listquery=con.prepareStatement(query);
			listquery.setString(1, fe);
			listquery.setString(2, branch);
			rs=listquery.executeQuery();
			while(rs.next())
			{
				Vector faculty=new Vector();
				faculty.addElement(rs.getString(1));
				faculty.addElement(rs.getString(2));
				flist.addElement(faculty);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		new DBConnection().releaseDatabaseConnection(con);
		return flist;
	
	}

}
