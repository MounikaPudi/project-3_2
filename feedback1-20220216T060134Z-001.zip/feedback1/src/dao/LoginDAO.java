package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LoginDAO {

	java.sql.Connection con;
	Statement st;
	ResultSet rs;
	public LoginDAO()
	{
		//con=new DBConnection().getDatabaseConnection();
		
	}
	public UserRecord getLoginDetails(String id,String pwd)
	{
		try {
			con=new DBConnection().getDatabaseConnection();
			
			st=con.createStatement();
			String query="select * from users where id=?";
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if(rs.next())
			{
				if(rs.getString(2).equals(pwd))
				{
					UserRecord ur=new UserRecord();
					ur.setLoginid(id);
					ur.setPwd(rs.getString(2));
					ur.setType(rs.getString(3));
					ur.setActive(rs.getInt(4));
					
					new DBConnection().releaseDatabaseConnection(con);
					return ur;
			    }
			}
			else
			{
				new DBConnection().releaseDatabaseConnection(con);
				return null;
			}
				
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return null;	
	}
	public String changePassword(UserRecord user,String opass,String newpass)
	{
		String query="select pwd from users where id='"+user.getLoginid()+"'";
		String uquery="update users set pwd=? where id=?";
		opass=opass.toUpperCase();
		newpass=newpass.toUpperCase();
		try {
			con=new DBConnection().getDatabaseConnection();
			
			PreparedStatement ups=con.prepareStatement(uquery);
			st=con.createStatement();
			rs=st.executeQuery(query);
			if(rs.next())
			{
				String opwd=rs.getString(1);
				if(opwd.equals(opass))
				{
				  	ups.setString(1, newpass);
				  	ups.setString(2, user.getLoginid());
				  	int res=ups.executeUpdate();
				  	new DBConnection().releaseDatabaseConnection(con);
				  	if(res>0)
				  		return "Password is successfully changed.";
				  	
				}
				else
					return "Old password is incorrect.Please try again.";
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return e.toString();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return null;
		
	}
}
