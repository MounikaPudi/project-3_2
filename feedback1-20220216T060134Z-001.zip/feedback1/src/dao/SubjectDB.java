package dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class SubjectDB {
	java.sql.Connection con;
	Statement st;
	ResultSet rs;
	int subjcode;
	public SubjectDB()
	{
//		con=new DBConnection().getDatabaseConnection();
	}
	public boolean insertSubject(Subject subj) throws SQLException
	{
	con=new DBConnection().getDatabaseConnection();
		PreparedStatement ps=con.prepareStatement("insert into subjects values(?,?,?,?,?,?,?,?)");
	
    st=con.createStatement();
    //String sid=getSubjectID(subj);
    
    //subj.setSid(sid);
    
    ps.setString(1, subj.getSid());
    ps.setString(2, subj.getSname());
    ps.setString(3,subj.getBranch());
    ps.setString(4,subj.getYear());
    ps.setString(5, subj.getSem());
    ps.setInt(6,0);
    ps.setString(7, subj.getAy());
    ps.setString(8, subj.getShrtname());
    
    int cnt=ps.executeUpdate();
    new DBConnection().releaseDatabaseConnection(con);
    if(cnt>0)
    	return true;
    return false;
       
    }
	private String getSubjectID(Subject subj) throws SQLException 
	{
		String query="select max(code) from subjects where branch=? and year=? and sem=? and ay=?";
		con=new DBConnection().getDatabaseConnection();
	    PreparedStatement psmt=con.prepareStatement(query);
	    
	    psmt.setString(1,subj.getBranch());
	    psmt.setString(2,subj.getYear() );
	    psmt.setString(3, subj.getSem());
	    psmt.setString(4, subj.getAy());
	    
	    int code=1;
	    rs=psmt.executeQuery();
	    
	    if(rs.next())
	    {
	    	code=rs.getInt(1);
	    }	
	    new DBConnection().releaseDatabaseConnection(con);
		String subjid=new String();
		String br=subj.getBranch();
		String y=subj.getYear();
		String s=subj.getSem();
		String brcode=new String();
		String ycode=new String();
		String scode=new String();
		if(br.equals("CIVIL"))
			brcode="1";
		else if(br.equals("E.E.E"))
			brcode="2";
		else if(br.equals("MECH"))
			brcode="3";
		else if(br.equals("E.C.E"))
			brcode="4";
		else if(br.equals("C.S.E"))
			brcode="5";
		else if(br.equals("I.T"))
			brcode="12";
		
		if(y.equals("I"))
			ycode="1";
		else if(y.equals("II"))
			ycode="2";
		else if(y.equals("III"))
			ycode="3";
		else if(y.equals("IV"))
			ycode="4";
		
		if(s.equals("I"))
			scode="1";
		else if(s.equals("II"))
			scode="2";
		String ayear=subj.getAy().substring(2,4);
		subjid=ayear+brcode+ycode+scode+(code+1);
		subjcode=code+1;
     return subjid;
	}
	
	public int uploadSubjects(String file)
	{
		 //fileName="E:\\EXAS\\stlist.xls";
        //Read an Excel File and Store in a Vector
        Vector dataHolder=readExcelFile(file);
        //Print the data read
        try {
			int cnt=printCellDataToConsole(dataHolder);
			if(cnt>0)
				return cnt;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return 0;
	}
	
	 public Vector readExcelFile(String fileName)
	    {
	        /** --Define a Vector
	            --Holds Vectors Of Cells
	         */
	        Vector cellVectorHolder = new Vector();

	        try{
	        /** Creating Input Stream**/
	        //InputStream myInput= ReadExcelFile.class.getResourceAsStream( fileName );
	        FileInputStream myInput = new FileInputStream(fileName);

	        /** Create a POIFSFileSystem object**/
	        POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

	        /** Create a workbook using the File System**/
	         HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

	         /** Get the first sheet from workbook**/
	        HSSFSheet mySheet = myWorkBook.getSheetAt(0);

	        /** We now need something to iterate through the cells.**/
	          Iterator rowIter = mySheet.rowIterator();

	          while(rowIter.hasNext()){
	              HSSFRow myRow = (HSSFRow) rowIter.next();
	              Iterator cellIter = myRow.cellIterator();
	              Vector cellStoreVector=new Vector();
	              while(cellIter.hasNext()){
	                  HSSFCell myCell = (HSSFCell) cellIter.next();
	                  cellStoreVector.addElement(myCell);
	              }
	              cellVectorHolder.addElement(cellStoreVector);
	          }
	        }catch (Exception e){e.printStackTrace(); }
	        return cellVectorHolder;
	    }
	 
	 private int printCellDataToConsole(Vector dataHolder) throws SQLException {
		 String query="insert into faculty values(?,?,?)";
		 con=new DBConnection().getDatabaseConnection();
			PreparedStatement ps=con.prepareStatement(query);
			int cnt=0;
            
	        for (int i=0;i<dataHolder.size(); i++){
	                   Vector cellStoreVector=(Vector)dataHolder.elementAt(i);
	         
	                   Subject subj=new Subject();
	            
	                
	                   HSSFCell scodecell = (HSSFCell)cellStoreVector.elementAt(0);
		                subj.setSid(scodecell.toString());
		                
	                HSSFCell snamecell = (HSSFCell)cellStoreVector.elementAt(1);
	                subj.setSname(snamecell.toString());
	                
	                HSSFCell branchcell = (HSSFCell)cellStoreVector.elementAt(2);
	                subj.setBranch(branchcell.toString());
	                
	                HSSFCell yearcell = (HSSFCell)cellStoreVector.elementAt(3);
	                subj.setYear(yearcell.toString());
	                
	                HSSFCell semcell = (HSSFCell)cellStoreVector.elementAt(4);
	                subj.setSem(semcell.toString());
	                
	                HSSFCell aycell = (HSSFCell)cellStoreVector.elementAt(5);
	                subj.setAy(aycell.toString());
	                
	                HSSFCell shrtcell = (HSSFCell)cellStoreVector.elementAt(6);
	                subj.setShrtname(shrtcell.toString());
	                
	                if(insertSubject(subj))
	                	cnt++;
	                
	         }
	        new DBConnection().releaseDatabaseConnection(con);        
	        return cnt;
	    }
	 
	 public Vector loadSubjectsList(String branch,String year,String sem,String ay)
	 {
		String query="select sid,subname from subjects where branch=? and year=? and sem=? and ay=?";
		Vector slist=new Vector();
		try {
			con=new DBConnection().getDatabaseConnection();
			PreparedStatement listquery=con.prepareStatement(query);
			listquery.setString(1, branch);
			listquery.setString(2, year);
			listquery.setString(3, sem);
			listquery.setString(4, ay);
			rs=listquery.executeQuery();
			while(rs.next())
			{
				Vector subject=new Vector();
				subject.addElement(rs.getString(1));
				subject.addElement(rs.getString(2));
				slist.addElement(subject);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return slist;
	 }
	 public String getSubjectName(String subj)
	 {
		 String query="select subname from subjects where sid=?";
			String fname=new String();
			try {
				con=new DBConnection().getDatabaseConnection();
				PreparedStatement listquery=con.prepareStatement(query);
				listquery.setString(1, subj);
				rs=listquery.executeQuery();
				
				if(rs.next())
				{
				  fname=rs.getString(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			new DBConnection().releaseDatabaseConnection(con);
			return fname;
		
	 }
	 public String getSubjectShortName(String subid)
	 {
		 String query="select shortname from subjects where sid=?";
			String fname=new String();
			try {
				con=new DBConnection().getDatabaseConnection();
				PreparedStatement listquery=con.prepareStatement(query);
				listquery.setString(1, subid);
				rs=listquery.executeQuery();
				
				if(rs.next())
				{
				  fname=rs.getString(1);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			new DBConnection().releaseDatabaseConnection(con);
			return fname;
		 
	 }
	public String getOESubjectName(String sid) {
		// TODO Auto-generated method stub
		if(sid.equals("UGBS0T0118"))  return "PROBABILITY & STATISTICS";
		 else if(sid.equals("UGBS0T0218"))  return "OPERATIONS RESEARCH";
		 else if(sid.equals("UGBS0T0318"))  return "NUMERICAL METHODS & COMPLEX VARIABLES";
		 else if(sid.equals("UGBS0T0418"))  return "OPTIMIZATION TECHNIQUES-I";
		 else if(sid.equals("UGBS0T0518"))  return "OPTIMIZATION TECHNIQUES-II";
		 else if(sid.equals("UGCE0T0118"))  return "RS & GIS AND ITS APPLICATIONS";
		 else if(sid.equals("UGCE0T0218"))  return "ELEMENTS OF TRANSPORTATION ENGINEERING";
		 else if(sid.equals("UGCE0T0318"))  return "WATER SUPPLY ENGINEERING.";
		 else if(sid.equals("UGCE0T0418"))  return "SANITARY ENGINEERING";
		 else if(sid.equals("UGCE0T0518"))  return "ENVIRONMENT POLLUTION.";
		 else if(sid.equals("UGCE0T0618"))  return "ELEMENTS OF DAM & IRRIGATION ENGINEERING.";
		 else if(sid.equals("UGCE0T0718"))  return "DISASTER MANAGEMENT";
		 else if(sid.equals("UGCE0T0818"))  return "BASIC ELEMENTS OF EARTHQUAKE ENGINEERING";
		 else if(sid.equals("UGCS0T0118"))  return "COMPUTER NETWORKS";
		 else if(sid.equals("UGCS0T0218"))  return "COMPUTER ORGANIZATION AND ARCHITECTURE";
		 else if(sid.equals("UGCS0T0318"))  return "DATABASE MANAGEMENT SYSTEMS";
		 else if(sid.equals("UGCS0T0418"))  return "DATA SCIENCE";
		 else if(sid.equals("UGCS0T0518"))  return "DESIGN AND ANALYSIS OF ALGORITHMS";
		 else if(sid.equals("UGCS0T0618"))  return "INTERNET OF THINGS";
		 else if(sid.equals("UGCS0T0718"))  return "LINUX PROGRAMMING";
		 else if(sid.equals("UGCS0T0818"))  return "OBJECT ORIENTED PROGRAMMING THROUGH C++";
		 else if(sid.equals("UGCS0T0918"))  return "OBJECT ORIENTED PROGRAMMING THROUGH JAVA";
		 else if(sid.equals("UGCS0T1018"))  return "OPERATING SYSTEMS";
		 else if(sid.equals("UGCS0T1118"))  return "PYTHON PROGRAMMING";
		 else if(sid.equals("UGEC0T0118"))  return "BASIC ELECTRONICS ENGINEERING";
		 else if(sid.equals("UGEC0T0218"))  return "APPLICATIONS OF ELECTRONIC DEVICES";
		 else if(sid.equals("UGEC0T0318"))  return "ANALOG & DIGITAL COMMUNICATION";
		 else if(sid.equals("UGEC0T0418"))  return "DATA COMMUNICATION";
		 else if(sid.equals("UGEC0T0518"))  return "MICROPROCESSORS AND MULTICORE SYSTEMS";
		 else if(sid.equals("UGEC0T0618"))  return "VLSI DESIGN";
		 else if(sid.equals("UGEC0T0718"))  return "IMAGE PROCESSING";
		 else if(sid.equals("UGEC0T0818"))  return "WAVELET TRANSFORMS";
		 else if(sid.equals("UGEC0T0918"))  return "EMBEDDED SYSTEMS";
		 else if(sid.equals("UGEC0T1018"))  return "MEMS";
		 else if(sid.equals("UGEC0T1118"))  return "ELECTRONIC INSTRUMENTATION";
		 else if(sid.equals("UGEE0T0118"))  return "ENERGY STUDIES";
		 else if(sid.equals("UGEE0T0218"))  return "ENERGY AUDIT AND CONSERVATION";
		 else if(sid.equals("UGEE0T0318"))  return "SENSORS & APPLICATIONS";
		 else if(sid.equals("UGEE0T0418"))  return "INDUSTRIAL ELECTRONICS";
		 else if(sid.equals("UGEE0T0518"))  return "ELECTRICAL MACHINES FOR EV'S";
		 else if(sid.equals("UGEE0T0618"))  return "PLC & APPLICATIONS";
		 else if(sid.equals("UGEE0T0718"))  return "SOLAR ENERGY APPLIANCES";
		 else if(sid.equals("UGEE0T0818"))  return "ENERGY STORAGE TECHNOLOGIES";
		 else if(sid.equals("UGEE0T0918"))  return "MATLAB";
		 else if(sid.equals("UGEE0T1018"))  return "AI TECHNIQUES";
		 else if(sid.equals("UGIT0T0118"))  return "DATA STRUCTURES";
		 else if(sid.equals("UGIT0T0218"))  return "SOFTWARE ENGINEERING";
		 else if(sid.equals("UGIT0T0318"))  return "WEB TECHNOLOGIES";
		 else if(sid.equals("UGIT0T0418"))  return "UNIX PROGRAMMING";
		 else if(sid.equals("UGIT0T0518"))  return "E-COMMERCE";
		 else if(sid.equals("UGIT0T0618"))  return "ARTIFICIAL INTELLIGENCE";
		 else if(sid.equals("UGIT0T0718"))  return "COMPUTER GRAPHICS";
		 else if(sid.equals("UGIT0T0818"))  return "CLOUD COMPUTING";
		 else if(sid.equals("UGIT0T0918"))  return "MACHINE LEARNING";
		 else if(sid.equals("UGIT0T1018"))  return "ADVANCED DATA STRUCTURES";
		 else if(sid.equals("UGIT0T1118"))  return "DESIGN AND ANALYSIS OF ALGORITHMS";
		 else if(sid.equals("UGIT0T1218"))  return "PARALLEL COMPUTING";
		 else if(sid.equals("UGIT0T1318"))  return "BIOINFORMATICS";
		 else if(sid.equals("UGIT0T1418"))  return "ADVANCED JAVA";
		 else if(sid.equals("UGME0T0118"))  return "METALLURGY AND MATERIAL SCIENCE";
		 else if(sid.equals("UGME0T0218"))  return "BASICS OF MECHANICAL ENGINEERING";
		 else if(sid.equals("UGME0T0318"))  return "ENGINEERING MECHANICS";
		 else if(sid.equals("UGME0T0418"))  return "STRENGTH OF MATERIALS";
		 else if(sid.equals("UGME0T0518"))  return "FLUID MACHINERY";
		 else if(sid.equals("UGME0T0618"))  return "NANOTECHNOLOGY";
		 else if(sid.equals("UGME0T0718"))  return "THERMODYNAMICS";
		 else if(sid.equals("UGME0T0818"))  return "THERMAL AND FLUID ENGINEERING";
		 else if(sid.equals("UGME0T0918"))  return "AUTOMOBILE ENGINEERING";
		 else if(sid.equals("UGME0T1018"))  return "COMPUTER AIDED ENGINEERING DRAWING";
		 else if(sid.equals("UGME0T1118"))  return "INDUSTRIAL ENGINEERING AND MANAGEMENT";
		 else if(sid.equals("UGME0T1218"))  return "QUALITY AND RELIABILITY ENGINEERING";
		return "";
		
	}
	public int deleteSubjects(String sem) {
		// TODO Auto-generated method stub
		String query="delete from subjects where sem ='"+sem+"'";
		String query1="delete from mapsubjects where sid in (select sid from subjects where sem='"+sem+"')";
		
		int cnt=0;
		Connection con=null;
		   try {
			   con=new DBConnection().getDatabaseConnection();
			   con.createStatement().executeUpdate(query1);  
			 cnt=con.createStatement().executeUpdate(query);
			 
		
			   
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new DBConnection().releaseDatabaseConnection(con);
		return cnt;


	}
	 
}
