import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Faculty;
import dao.FacultyDB;
import dao.FacultyData;
import dao.FacultyDataDB;
import dao.FeedBackDB;
import dao.LoginDAO;
import dao.MapSubject;
import dao.MapSubjectDB;
import dao.Student;
import dao.StudentDB;
import dao.StudentData;
import dao.StudentDataDB;
import dao.Subject;
import dao.SubjectDB;
import dao.UserRecord;


public class FBSAction extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	
	public FBSAction() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session=request.getSession(true);
		
		String page=(String)request.getParameter("option");
		
		if(page==null)
			page=(String)session.getAttribute("option");

		//System.out.println(page);
		if(page.equals("Login"))
		{
			processLoginDetails(request,response);
		}
		else if(page.equals("logout"))
		{
			processLogout(request,response);
		}
		else if(page.equals("sentry"))
		{
			response.sendRedirect("./studentsEntry1.jsp");
		}
		else if(page.equals("stmanualentry"))
		{
			processStManualDetails(request,response);
		}
		else if(page.equals("studentsimport"))
		{
			processStudentExcelFile(request,response);
		}
		else if(page.equals("facultyimport"))
		{
			processFacultyExcelFile(request,response);
		}
		else if(page.equals("subjectsimport"))
		{
			processSubjectsExcelFile(request,response);
		}
		else if(page.equals("fentry"))
		{
			response.sendRedirect("./FacultyEntry.jsp");
		}
		else if(page.equals("ftmanualentry"))
		{
			processFtManualDetails(request,response);
		}
		else if(page.equals("subjentry"))
		{
			response.sendRedirect("./SubjectEntry.jsp");
		}
		else if(page.equals("subjmanualentry"))
		{
			processSubjectManualDetails(request,response);
		}
		else if(page.equals("smap"))
		{
			response.sendRedirect("./MapSubject1.jsp");
		}
		else if(page.equals("MapSubject"))
		{
			processSubjectMappingDetails(request,response);
		}
		else if(page.equals("fdentry"))
		{
			boolean valid=checkForEntry((UserRecord)session.getAttribute("LoginRecord"));
			if(valid)
			response.sendRedirect("./fdentry.jsp");
			else
			{
				session.setAttribute("fdresult","Your FeedBack on Faculty is already completed.<br></br> You are not allowed to submit the FeedBack further.");
				response.sendRedirect("./feedbackerror.jsp");
			}

		}
		else if(page.equals("feentry"))
		{
			boolean valid=checkForFEEntry((UserRecord)session.getAttribute("LoginRecord"));
			if(valid)
			response.sendRedirect("./feselect.jsp");
			else
			{
				session.setAttribute("fdresult","Your FeedBack on Foundation Elective is already completed.<br></br> You are not allowed to submit the FeedBack further.");
				response.sendRedirect("./feedbackerror.jsp");
			}

		}
		else if(page.equals("oeentry"))
		{
			response.sendRedirect("./oeselect.jsp");
			

		}

		else if(page.equals("mbaelentry"))
		{
			//boolean valid=checkForMBAElEntry((UserRecord)session.getAttribute("LoginRecord"));
			//if(valid)
			response.sendRedirect("./mbaelselect.jsp");
			/*else
			{
				session.setAttribute("fdresult","Your FeedBack on MBA Elective is already completed.<br></br> You are not allowed to submit the FeedBack further.");
				response.sendRedirect("./feedbackerror.jsp");
			}*/

		}

		else if(page.equals("fdbentry"))
		{
			processFeedbackEntryFields(request,response);
		}
		else if(page.equals("fedentry"))
		{
			processFEFeedbackEntryFields(request,response);
		}

		else if(page.equals("freport"))
		{
			response.sendRedirect("./BranchSelection.jsp");
		}
		else if(page.equals("deptreport"))
		{
			response.sendRedirect("./DeptSelection.jsp");
		}
		else if(page.equals("classreport"))
		{
			session=request.getSession(true);
			session.setAttribute("report", "class");
			response.sendRedirect("./ClassSelection.jsp");
		}
		else if(page.equals("fereport"))
		{
			session=request.getSession(true);
			session.setAttribute("report", "fereport");
			response.sendRedirect("./ClassSelection.jsp");
		}
		else if(page.equals("aggregatereport"))
		{
			session.setAttribute("report", "aggregate");
			response.sendRedirect("./ClassSelection.jsp");
		}
		else if(page.equals("FEMapSubject"))
		{
			processFEMap(request,response);
		}
		else if(page.equals("OEMapSubject"))
		{
			processOEMap(request,response);
		}
		else if(page.equals("mbaelmapsubject"))
		{
			processFEMap(request,response);
		}
		else if(page.equals("changepwd"))
		{
	       processPassword(request,response);		
		}
		else if(page.equals("mapdelete"))
		{
			response.sendRedirect("./DeleteSubjectMapping1.jsp");
		}
		else if(page.equals("fbstatus"))
		{
			response.sendRedirect("./fbstatus.jsp");
		}
		else if(page.equals("stdelete"))
		{
			response.sendRedirect("./studentDeletion.jsp");
		}
		else if(page.equals("fdelete"))
		{
			response.sendRedirect("./fdelete.jsp");
		}
		else if(page.equals("promote"))
		{
			response.sendRedirect("./studentpromotion.jsp");
		}
		else if(page.equals("stprofile"))
		{
			response.sendRedirect("./updateprofile.jsp");
		}
		else if(page.equals("backup"))
		{
			
			response.sendRedirect("./backupprogress.jsp");
		}

	}
	private void processFEFeedbackEntryFields(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		Vector feedback=new Vector();
		StudentData stdata=(StudentData)session.getAttribute("stdata");
		Student stdnt=stdata.getStdnt();
		String subid=session.getValue("subject").toString();
		String fid=session.getValue("faculty").toString();
		//System.out.println("After feedback"+stdnt.getSno());
		
			String mapid=subid+"-"+fid;
			
			Vector fdbentry=new Vector();
			String studentID=stdnt.getSno();
			String fdid=mapid+"-"+studentID;
			
			fdbentry.addElement(fdid);
			fdbentry.addElement(mapid);
			fdbentry.addElement(studentID);
			
			int sum=0;
			for(int j=1;j<=3;j++)
			{
				String paramName=subid+"A"+j;
				String val=request.getParameter(paramName);
			 //   System.out.println("val="+val);
			    
				fdbentry.addElement(val);
				
				sum=sum+Integer.parseInt(val);
			}
			
			int bsum=0;
			for(int k=1;k<=4;k++)
			{
				String paramName=subid+"B"+k;
				String val=request.getParameter(paramName);
				fdbentry.addElement(val);
				bsum=bsum+Integer.parseInt(val);
			}
			
			
			int csum=0;
			for(int m=1;m<=3;m++)
			{
				String paramName=subid+"C"+m;
				String val=request.getParameter(paramName);
				fdbentry.addElement(val);
				csum=csum+Integer.parseInt(val);
			}
			
			
			int dsum=0;
			for(int n=1;n<=3;n++)
			{
				String paramName=subid+"D"+n;
				String val=request.getParameter(paramName);
				fdbentry.addElement(val);
				dsum=dsum+Integer.parseInt(val);
			}
			int totsum=sum+bsum+csum+dsum;
			fdbentry.addElement(new Integer(sum));
			fdbentry.addElement(new Integer(bsum));
			fdbentry.addElement(new Integer(csum));
			fdbentry.addElement(new Integer(dsum));
			fdbentry.addElement(new Integer(totsum));
			
			feedback.addElement(fdbentry);
		
		
		FeedBackDB fdb=new FeedBackDB();
		int cnt=fdb.insertFeedbackEntries(feedback);
		
		if(cnt>0)
			session.setAttribute("fdresult",cnt+" Subjects Feedback entries are successfully stored.");
		else
			session.setAttribute("fdresult","Subjects Feedback entries are not successfully stored");
			
		try {
			response.sendRedirect("./FeedBackEntryResult.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

	private void processFEMap(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		String mapid=request.getParameter("mapid");
		String ay=request.getParameter("ay");
		String fid=request.getParameter("fid");
		String subject=request.getParameter("subjid");
		
		MapSubject ms=new MapSubject();
		ms.setMapid(mapid);
		ms.setSubjid(subject);
		ms.setFid(fid);
		ms.setAy(ay);
		
		HttpSession session=request.getSession(true);
		MapSubjectDB msdb=new MapSubjectDB();
		boolean res=msdb.insertFEMapping(ms);
		if(res)
		{
			session.setAttribute("subjmapresult","Subject is successfully Mapped with Faculty");
			String subjname=new SubjectDB().getSubjectName(ms.getSubjid());
			session.setAttribute("mappedsubject", subjname);
		}
		else
			session.setAttribute("subjmapresult","Subject is not mapped with faculty");
			
		try {
			response.sendRedirect("./SubjectMapResult.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void processOEMap(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		String mapid=request.getParameter("mapid");
		String ay=request.getParameter("ay");
		String fid=request.getParameter("fid");
		String subject=request.getParameter("subjid");
		String branch=request.getParameter("branch");
		
		MapSubject ms=new MapSubject();
		ms.setMapid(mapid);
		ms.setSubjid(subject);
		ms.setFid(fid);
		ms.setAy(ay);
		ms.setBranch(branch);
		
		HttpSession session=request.getSession(true);
		MapSubjectDB msdb=new MapSubjectDB();
		boolean res=msdb.insertOEMapping(ms);
		if(res)
		{
			session.setAttribute("subjmapresult","Subject is successfully Mapped with Faculty");
			String subjname=new SubjectDB().getSubjectName(ms.getSubjid());
			session.setAttribute("mappedsubject", subjname);
		}
		else
			session.setAttribute("subjmapresult","Subject is not mapped with faculty");
			
		try {
			response.sendRedirect("./SubjectMapResult.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public void processStatus(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		 String branch=request.getParameter("branch");
		 String year=request.getParameter("year");
		 String sem=request.getParameter("sem");
		 String sec=request.getParameter("sec");
		 FeedBackDB fdb=new FeedBackDB();
		 fdb.loadAttemptedList(branch,year,sem,sec);
		 fdb.loadNotAttemptedList(branch,year,sem,sec);
		 response.sendRedirect("./fbstatus");
		 
	
	}
	public void processLogout(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		HttpSession session=request.getSession(true);
		session.removeAttribute("LoginRecord");
		session.invalidate();
		response.sendRedirect("./index.jsp");
	}
	public void processPassword(HttpServletRequest request, HttpServletResponse response)throws IOException
	{
		String opass=request.getParameter("opass");
		String newpass=request.getParameter("npass");
		
		HttpSession session=request.getSession(true);
		UserRecord user=(UserRecord)session.getAttribute("LoginRecord");
		LoginDAO login=new LoginDAO();
		String res=login.changePassword(user,opass,newpass);
		session.setAttribute("passres", res);
		response.sendRedirect("./passwordstatus.jsp");
		
		
	}
	public boolean checkForEntry(UserRecord ur)
	{
	  FeedBackDB fdb=new FeedBackDB();
	  boolean valid=fdb.checkForFdbEntry(ur);
	  return valid;
	}
	public boolean checkForFEEntry(UserRecord ur)
	{
	  FeedBackDB fdb=new FeedBackDB();
	  boolean valid=fdb.checkForFEEntry(ur);
	  return valid;
	}
	public boolean checkForOEEntry(UserRecord ur)
	{
	  FeedBackDB fdb=new FeedBackDB();
	  boolean valid=fdb.checkForFEEntry(ur);
	  return valid;
	}
	public boolean checkForMBAElEntry(UserRecord ur)
	{
	  FeedBackDB fdb=new FeedBackDB();
	  boolean valid=fdb.checkForMBAElEntry(ur);
	  return valid;
	}
	public void processFeedbackEntryFields(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		HttpSession session=request.getSession(true);
		Vector feedback=new Vector();
		StudentData stdata=(StudentData)session.getAttribute("stdata");
		Student stdnt=stdata.getStdnt();
		Vector subjects=stdata.getSubjects();
		//System.out.println("After feedback"+stdnt.getSno());
		for(int i=0;i<subjects.size();i++)
		{
			Vector totsub=(Vector)subjects.elementAt(i);
			Subject sub=(Subject)totsub.elementAt(0);
			String mapid=(String)totsub.elementAt(2);
			
			Vector fdbentry=new Vector();
			String subname=sub.getSid();
			String studentID=stdnt.getSno();
			String fdid=mapid+studentID;
			
			fdbentry.addElement(fdid);
			fdbentry.addElement(mapid);
			fdbentry.addElement(studentID);
			
			int sum=0;
			for(int j=1;j<=3;j++)
			{
				String paramName=subname+"A"+j;
				String val=request.getParameter(paramName);
			 //   System.out.println("val="+val);
			    
				fdbentry.addElement(val);
				
				sum=sum+Integer.parseInt(val);
			}
			
			int bsum=0;
			for(int k=1;k<=4;k++)
			{
				String paramName=subname+"B"+k;
				String val=request.getParameter(paramName);
				fdbentry.addElement(val);
				bsum=bsum+Integer.parseInt(val);
			}
			
			
			int csum=0;
			for(int m=1;m<=3;m++)
			{
				String paramName=subname+"C"+m;
				String val=request.getParameter(paramName);
				fdbentry.addElement(val);
				csum=csum+Integer.parseInt(val);
			}
			
			
			int dsum=0;
			for(int n=1;n<=3;n++)
			{
				String paramName=subname+"D"+n;
				String val=request.getParameter(paramName);
				fdbentry.addElement(val);
				dsum=dsum+Integer.parseInt(val);
			}
			int totsum=sum+bsum+csum+dsum;
			fdbentry.addElement(new Integer(sum));
			fdbentry.addElement(new Integer(bsum));
			fdbentry.addElement(new Integer(csum));
			fdbentry.addElement(new Integer(dsum));
			fdbentry.addElement(new Integer(totsum));
			
			feedback.addElement(fdbentry);
		
		}
		FeedBackDB fdb=new FeedBackDB();
		int cnt=fdb.insertFeedbackEntries(feedback);
		
		if(cnt>0)
			session.setAttribute("fdresult",cnt+" Subjects Feedback entries are successfully stored.");
		else
			session.setAttribute("fdresult","Subjects Feedback entries are not successfully stored");
			
		response.sendRedirect("./FeedBackEntryResult.jsp");
	
		
	}
	public void processSubjectMappingDetails(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		HttpSession session=request.getSession(true);
		MapSubject ms=new MapSubject();
		ms.setMapid(request.getParameter("mapid"));
		ms.setFid(request.getParameter("fid"));
		ms.setSubjid(request.getParameter("subjid"));
		ms.setSec(request.getParameter("sec"));
		ms.setAy(request.getParameter("ay"));
		
		MapSubjectDB msdb=new MapSubjectDB();
		boolean res=msdb.insertMapping(ms);
		if(res)
		{
			session.setAttribute("subjmapresult","Subject is successfully Mapped with Faculty");
			String subjname=new SubjectDB().getSubjectName(ms.getSubjid());
			session.setAttribute("mappedsubject", subjname);
		}
		else
			session.setAttribute("subjmapresult","Subject is not mapped with faculty");
			
		response.sendRedirect("./SubjectMapResult.jsp");
	
		
	}
	
	public void processSubjectManualDetails(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		HttpSession session=request.getSession(true);
		Subject subj=new Subject();
		//subj.setSid(request.getParameter("sno"));
		subj.setSid(request.getParameter("subcode"));
		subj.setSname(request.getParameter("subname"));
		subj.setShrtname(request.getParameter("shrtname"));
		subj.setBranch(request.getParameter("branch"));
		subj.setYear(request.getParameter("year"));
		subj.setSem(request.getParameter("sem"));
		subj.setAy(request.getParameter("ay"));
		
		SubjectDB sdb=new SubjectDB();
		boolean res=false;
		try {
			res = sdb.insertSubject(subj);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res)
			session.setAttribute("subjentryresult","Subject Details are successfully created");
		else
			session.setAttribute("subjentryresult","Subject Details are not created");
			
		response.sendRedirect("./SubjectEntryResult.jsp");
		
	}
	
	public void processSubjectsExcelFile(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		HttpSession session =request.getSession(true);
		String lfile="e://excelfiles//" +  session.getAttribute("filename").toString();
    	SubjectDB ftdb=new SubjectDB();
		int cnt=ftdb.uploadSubjects(lfile);
		if(cnt>0)
			session.setAttribute("subjentryresult",cnt+" subject Details are successfully created");
		else
			session.setAttribute("subjentryresult","subject Details are not created");
			
		response.sendRedirect("./SubjectEntryResult.jsp");
	
	}
	public void processFacultyExcelFile(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		
		HttpSession session =request.getSession(true);
		String lfile="e://excelfiles//" +  session.getAttribute("filename").toString();
		FacultyDB ftdb=new FacultyDB();
		int cnt=ftdb.uploadFaculty(lfile);
		if(cnt>0)
			session.setAttribute("ftentryresult",cnt+" Faculty Details are successfully created");
		else
			session.setAttribute("ftentryresult","Faculty Details are not created");
			
		response.sendRedirect("./FacultyEntryResult.jsp");
	
	}
	public void processFtManualDetails(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		HttpSession session=request.getSession(true);
		Faculty newft=new Faculty();
		newft.setFid(request.getParameter("fid").toString());
		newft.setFname(request.getParameter("fname").toString());
		newft.setDept(request.getParameter("dept").toString());
		
		FacultyDB stdb=new FacultyDB();
		boolean res=false;
		try {
			res = stdb.insertFaculty(newft);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res)
			session.setAttribute("ftentryresult","Faculty Details are successfully created");
		else
			session.setAttribute("ftentryresult","Faculty Details are not created");
			
		response.sendRedirect("./FacultyEntryResult.jsp");
		
	}

	public void processStudentExcelFile(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		HttpSession session =request.getSession(true);
		String lfile="e://excelfiles//" +  session.getAttribute("filename").toString();
		//System.out.println(lfile);
		StudentDB stdb=new StudentDB();
		int cnt=stdb.uploadStudents(lfile);
		if(cnt>0)
			session.setAttribute("stentryresult",cnt+" Student Details are successfully created");
		else
			session.setAttribute("stentryresult","Student Details are not created");
			
		response.sendRedirect("./studentsEntryResult.jsp");
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		doPost(request,response);
	}
	
	public void processStManualDetails(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		HttpSession session=request.getSession(true);
		Student newst=new Student();
		newst.setSno(request.getParameter("sno"));
		newst.setSname(request.getParameter("sname"));
		newst.setBranch(request.getParameter("branch"));
		newst.setSection(request.getParameter("section"));
		newst.setYear(request.getParameter("year"));
		newst.setSem(request.getParameter("sem"));
		
		StudentDB stdb=new StudentDB();
		boolean res=false;
		try {
			res = stdb.insertStudent(newst);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res)
			session.setAttribute("stentryresult","Student Details are successfully inserted");
		else
			session.setAttribute("stentryresult","Student Details are not successfully inserted");
			
		response.sendRedirect("./studentsEntryResult.jsp");
		
		
		
		
	}

	
	public void processLoginDetails(HttpServletRequest request, HttpServletResponse response) throws IOException
	{
		HttpSession session=request.getSession(true);
		String id=request.getParameter("loginid").toUpperCase();
		String pwd=request.getParameter("pwd").toUpperCase();
		session=request.getSession(true);
		
		LoginDAO ldao=new LoginDAO();
		UserRecord ur=ldao.getLoginDetails(id,pwd);
		
		if(ur!=null)
		{
			
            session.setAttribute("LoginRecord", ur);
            String type=ur.getType();
            if(type.equals("student"))
            {
            	StudentDataDB fdb=new StudentDataDB();
            	StudentData sfb=fdb.loadStdntData(ur.getLoginid());
            	
            	session.setAttribute("stdata", sfb);
            	//System.out.println("Login:"+sfb.getStdnt().getSno());
            	response.sendRedirect("./studentmain.jsp");
            }
            else if(type.equals("faculty"))
            {
            	FacultyDataDB fadb=new FacultyDataDB();
            	FacultyData fdata=fadb.loadFacultyData(ur.getLoginid());
            	
            	session.setAttribute("facultydata", fdata);
            	
            	response.sendRedirect("./facultymain.jsp");
            }
            else if(type.equals("admin"))
            	response.sendRedirect("./adminmain.jsp");
            else if(type.equals("hod"))
            	response.sendRedirect("./hodmain.jsp");
            else if(type.equals("principal"))
            	response.sendRedirect("./principalmain.jsp");
            
         }
		else
		{

    		session.setAttribute("StatusMessage", "Invalid Login.Please Try again");	        		
            session.setAttribute("LoginFacultyRecord", null);
            response.sendRedirect("./index.jsp");
        
		}
	}
	

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
