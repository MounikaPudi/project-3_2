

import java.io.IOException;
import java.sql.Connection;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

import dao.DBConnection;
import dao.FBSFetchDataBean;
import dao.FBSMiscUtilitiesBean;
import dao.FacultyReportDB;

/**
 * Servlet implementation class ReportViewer
 */
public class FacultyFeedbackReport1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
 Connection con;       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FacultyFeedbackReport1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	    try
	    {
	    	String dept=request.getParameter("dept");
	    	if(dept.equals("B.S"))
	    		dept="Basic Science";
	    	String fname=new FBSFetchDataBean().getFacultyName(request.getParameter("faculty"));
	    	System.out.println(dept+" "+fname);
	    	
	    	FacultyReportDB report=new FacultyReportDB();
	        report.loadData(dept,fname);
		    
	        
	        con=new DBConnection().getDatabaseConnection();
		    /*(Here the parameter file should be in .jasper extension
		i.e., the compiled report)*/

		//JasperExportManager.exportReportToPdfFile(print, "report1.pdf");
	  HashMap params=new HashMap();
	  params.put("name",fname);
	  dept.trim();
	  
	  params.put("dept",getDeptName(dept));
	  FBSMiscUtilitiesBean fs= new FBSMiscUtilitiesBean();;
		 String dt=fs.getSystemDate("dd/MM/yyyy");
		// System.out.println(dt);
		 params.put("curdate",dt);
	  
		    
		//JasperPrint print = JasperFillManager.fillReport(fileName, hm, new JREmptyDataSource());
	  
		    JasperReport jReport=JasperCompileManager.compileReport("e:\\reports\\faculty1.jrxml");	    
		JasperPrint print = JasperFillManager.fillReport(jReport, params,con);
		// Create a PDF exporter
		JRExporter exporter = new JRPdfExporter();
		// JRExporter exporter = new JRHtmlExporter();
		//JRExporter exporter = new JRXlsExporter();
		// Configure the exporter (set output file name and print object)
		String outFileName = "e:/reports/faculty1.pdf";
		exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, outFileName);
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);

		// Export the PDF file
		exporter.exportReport();
		

	    
		
		
		
		
		Document document=new Document();

	response.setContentType("application/pdf");
	PdfWriter writer=PdfWriter.getInstance(document,response.getOutputStream());

	document.open();

	PdfReader reader = new PdfReader("e:/reports/faculty1.pdf");
	int n = reader.getNumberOfPages();
	PdfImportedPage page;
	// Go through all pages
	for (int i = 1; i <= n; i++) {
		// Only page number 2 will be included
		
			page = writer.getImportedPage(reader, i);
			Image instance = Image.getInstance(page);
			document.add(instance);
		
	}
	document.close();
	    }

	    catch(JRException jre)
	    {
	    	jre.printStackTrace();

	    } catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    new DBConnection().releaseDatabaseConnection(con);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req,resp);
	}
	public String getDeptName(String dept)
	{
	   if(dept.equals("I.T"))
		   return "Information Technology(IT)";
		   else if(dept.equals("C.S.E"))
			   return "Computer Science(CSE)";
		   else if(dept.equals("E.C.E"))
			   return "Electronics and Communications(ECE)";
		   else if(dept.equals("E.E.E"))
			   return "Electrical and Electronics(EEE)";
		   else if(dept.equals("MECH"))
			   return "Mechanical";
		   else if(dept.equals("CIVIL"))
			   return "Civil";
		   else if(dept.equals("M.C.A"))
			   return "MCA";
		   else if(dept.equals("M.B.A"))
			   return "MBA";
	   return "";
	    }

}
