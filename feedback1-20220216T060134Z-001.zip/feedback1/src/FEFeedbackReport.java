

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

import dao.ClassReportDB;
import dao.DBConnection;
import dao.FBSMiscUtilitiesBean;

/**
 * Servlet implementation class FEFeedbackReport
 */
public class FEFeedbackReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FEFeedbackReport() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection con=null;
		try
	    {
	    	FBSMiscUtilitiesBean miscUtil=new FBSMiscUtilitiesBean();
	    	 String ay=miscUtil.noNull(request.getParameter("ay"));
	    	 String class1=miscUtil.noNull(request.getParameter("class1"));
	    	 
	    	HttpSession session=request.getSession(true);  
	    	//String type=session.getAttribute("report").toString();
	    	//String fname=new FBSFetchDataBean().getFacultyName(request.getParameter("faculty"));
	    	
	    	ClassReportDB report=new ClassReportDB();
	        report.loadFEData(class1,ay);
		   
		    		    
		    ReportGeneration rg=new ReportGeneration();
	         con=new DBConnection().getDatabaseConnection();
	        
	        rg.createPDF(con,"fe");
	        


	        Document document = new Document( PageSize.A4,30,36,25,36 );

	response.setContentType("application/pdf");
	PdfWriter writer=PdfWriter.getInstance(document,response.getOutputStream());

	document.open();

	PdfReader reader = new PdfReader("e:/reports/facultyPDF.pdf");
	int n = reader.getNumberOfPages();
	PdfImportedPage page;
	// Go through all pages
	for (int i = 1; i <= n; i++) {
		// Only page number 2 will be included
		
			page = writer.getImportedPage(reader, i);
			Image instance = Image.getInstance(page);
			document.add(instance);
		
	}
	document.close();
	    }

	    catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    new DBConnection().releaseDatabaseConnection(con);
	}


	}


