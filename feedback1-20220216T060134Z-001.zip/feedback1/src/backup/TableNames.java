package backup;

import java.sql.*;
import dao.*;
import java.util.Vector;

public class TableNames {

	/**
	 * @param args
	 */
	public Vector getNames() {
		
		
		  //System.out.println("Listing all table name in Database!");
		  Vector names=new Vector();
		
		  try{
		  Connection con=new DBConnection().getDatabaseConnection();
		  DatabaseMetaData dbm = con.getMetaData();
		  String[] types = {"TABLE"};
		  ResultSet rs = dbm.getTables(null,"ADMIN","%",types);
		 // System.out.println("Table name:");
		  while (rs.next()){
		  String table = rs.getString("TABLE_NAME");
		  names.add(table);
		  //System.out.println(table);
		  }
		  con.close();
		  }
		  catch (SQLException s){
		  System.out.println(s);
		  }
		return names;  
		  }
	   
		
		// TODO Auto-generated method stub

	}


