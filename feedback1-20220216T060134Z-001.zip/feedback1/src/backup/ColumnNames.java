package backup;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import dao.DBConnection;

public class ColumnNames {

	/**
	 * @param args
	 */
	public Vector getNames(String tabname) {
		// TODO Auto-generated method stub
		
		// System.out.println("Listing all column name in Database!");
		  Vector names=new Vector();
		
		  try{
		  Connection con=new DBConnection().getDatabaseConnection();
		  DatabaseMetaData dbm = con.getMetaData();
		  
		  String tableName = tabname;
	      java.sql.ResultSet rs = dbm.getColumns(null, "ADMIN", tableName, "%");
	      while (rs.next()) {
	        String colName = rs.getString(4);
	        names.add(colName);
	       // System.out.println(colName);
	      }
	        		  
		  /*String[] types = {"TABLE"};
		  ResultSet rs = dbm.getTables(null,"ADMIN","%",types);
		  System.out.println("Table name:");
		  while (rs.next()){
		  String table = rs.getString("TABLE_NAME");
		  names.add(table);
		  System.out.println(table);
		  }*/
	      
		  con.close();
		  }
		  catch (SQLException s){
		  System.out.println(s);
		  }
		return names;  


	}

}
