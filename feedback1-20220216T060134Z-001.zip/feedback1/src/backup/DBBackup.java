package backup;

import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Vector;

import dao.DBConnection;

public class DBBackup {

	/**
	 * @param args
	 */
	
	public String doBackup()
	{
		Calendar cal = new GregorianCalendar();
		  int month = cal.get(Calendar.MONTH);
		  int year = cal.get(Calendar.YEAR);
		  int day = cal.get(Calendar.DAY_OF_MONTH);
		  int hh=cal.get(Calendar.HOUR_OF_DAY);
		  int mm=cal.get(Calendar.MINUTE);

		  String strdate=day+"."+month+"."+year+"_"+hh+"HRS_"+mm+"MNTS";
		  String dirname = "e:\\feedbackbackup\\"+strdate;

		 try{
			 new File(dirname).mkdir();


			  Connection con=new DBConnection().getDatabaseConnection();
			  
			  TableNames ta=new TableNames();
			  Vector tabnames=ta.getNames();
			  for(int i=0;i<tabnames.size();i++)
			  {
				  String tabname=tabnames.get(i).toString();
				  
				  String filename=dirname+"\\"+tabname+".csv";
				  FileWriter fw = new FileWriter(filename);
				  
				  
				  ColumnNames cn=new ColumnNames();
				  Vector colnames=cn.getNames(tabname);
				  //System.out.println(colnames);
				  int j;
				  for(j=0;j<colnames.size()-1;j++)
				  {
					  fw.append(colnames.get(j).toString());
					  fw.append(',');
				  }
				  fw.append(colnames.get(j).toString());
				  fw.append('\n');
				  ResultSet rs=con.createStatement().executeQuery("select * from "+tabname);
				  
				  while(rs.next())
				  {
					  for(j=0;j<colnames.size()-1;j++)
					  {
						  fw.append(rs.getString(j+1));
						  fw.append(',');
					  }
					  fw.append(rs.getString(j+1));
					  fw.append('\n');
				  }
				  
				  
				  
				  fw.close();
			  }
			  Thread.sleep(1000);
			  return "DataBase Back Up is successfully Completed.\nPlease refer \"feedbackbackup\" folder in E Drive";
		 }
			  catch(Exception e)
			  {
				  return e.toString();
			  }
			
			 


	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calendar cal = new GregorianCalendar();
		  int month = cal.get(Calendar.MONTH);
		  int year = cal.get(Calendar.YEAR);
		  int day = cal.get(Calendar.DAY_OF_MONTH);
		  int hh=cal.get(Calendar.HOUR_OF_DAY);
		  int mm=cal.get(Calendar.MINUTE);

		  String strdate=day+"."+month+"."+year+"_"+hh+"HRS_"+mm+"MNTS";
		  String dirname = "e:\\feedbackbackup\\"+strdate;

		 try{
			 new File(dirname).mkdir();
			  
			  Connection con=new DBConnection().getDatabaseConnection();
			  
			  TableNames ta=new TableNames();
			  Vector tabnames=ta.getNames();
			  for(int i=0;i<tabnames.size();i++)
			  {
				  String tabname=tabnames.get(i).toString();
				  
				  String filename=dirname+"\\"+tabname+".csv";
				  FileWriter fw = new FileWriter(filename);
				  
				  
				  ColumnNames cn=new ColumnNames();
				  Vector colnames=cn.getNames(tabname);
				  //System.out.println(colnames);
				  int j;
				  for(j=0;j<colnames.size()-1;j++)
				  {
					  fw.append(colnames.get(j).toString());
					  fw.append(',');
				  }
				  fw.append(colnames.get(j).toString());
				  fw.append('\n');
				  ResultSet rs=con.createStatement().executeQuery("select * from "+tabname);
				  
				  while(rs.next())
				  {
					  for(j=0;j<colnames.size()-1;j++)
					  {
						  fw.append(rs.getString(j+1));
						  fw.append(',');
					  }
					  fw.append(rs.getString(j+1));
					  fw.append('\n');
				  }
				  
				  
				  
				  fw.close();
			  }
			  
			  System.out.println("DataBase Back Up is successfully Completed.Please refer \"feedbackbackup\" folder in E Drive");
		 }
			  catch(Exception e)
			  {
				  System.out.println(e);
			  }
			
			 

	}

}
