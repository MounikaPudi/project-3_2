import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;


public class PdfTable {

	/**
	 * @param args
	 * @throws DocumentException 
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		OutputStream file=null;
		try {
			file = new FileOutputStream(new File("e:\\Test.pdf"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Document doc = new Document();    
		try {
			PdfWriter.getInstance(doc, file);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		doc.open(); 
		PdfPTable table = new PdfPTable(3);
		PdfPCell cell = new PdfPCell(new Phrase("Header spanning 3 columns"));
		cell.setColspan(3);
		cell.setHorizontalAlignment(0); //0=Left, 1=Centre, 2=Right
		
		table.addCell(cell);
		table.addCell("Col 1 Row 1");
		table.addCell("Col 2 Row 1");
		table.addCell("Col 3 Row 1");
		table.addCell("Col 1 Row 2");
		table.addCell("Col 2 Row 2");
		table.addCell("Col 3 Row 2");
		
		try {
			doc.add(table);
			doc.close();
			file.close();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	System.out.println("Document created");



	}

}
