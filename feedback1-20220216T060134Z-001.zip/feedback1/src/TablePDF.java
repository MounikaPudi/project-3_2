import java.io.FileOutputStream;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import dao.FacultyDB;


public class TablePDF {
	private static String FILE = "e:/reports/deptreport.pdf";
	public void createPDF(String sysdate,String dept,Hashtable facultydata)
	{
		try {
			Document document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream(FILE));
			document.open();
			addTitlePage(document,sysdate,dept,facultydata);
		//	addContent(document);
			document.close();
			//System.out.println("Document is created");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	public void addTitlePage(Document document,String sysdate,String deptv,Hashtable facultydata) throws DocumentException 
	{
		Font font = new Font(Font.TIMES_ROMAN);
		font.setStyle(Font.BOLD);
		font.setSize(18);
		
		//preface.setFont(font);
//		preface.setAlignment(Element.ALIGN_CENTER);
		Paragraph title=new Paragraph("SHRI VISHNU ENGINEERING COLLEGE FOR WOMEN::BHIMAVARAM");
		Paragraph subtitle=new Paragraph("FEEDBACK ON FACULTY BY STUDENTS");
		title.setFont(font);
		subtitle.setFont(font);
		title.setAlignment(Element.ALIGN_CENTER);
		subtitle.setAlignment(Element.ALIGN_CENTER);
		document.add(title);
		document.add(subtitle);
		String acy=facultydata.get("ay").toString();
		//System.out.println("ay:"+acy);
		facultydata.remove("ay");
		Chunk ay=new Chunk("ACADEMIC YEAR:"+acy);
		Chunk dt=new Chunk("DATE:"+sysdate);
		Paragraph aydt=new Paragraph();
		for(int i=0; i<4; i++){
			Chunk tab = new Chunk("     ");
	        aydt.add(tab);
	      }
		aydt.add(ay);
		for(int i=0; i<8; i++){
			Chunk tab = new Chunk("     ");
	        aydt.add(tab);
	      }
		aydt.add(dt);
		document.add(new Paragraph(" "));
		document.add(aydt);
		
		
		Paragraph dept=new Paragraph();
		Chunk depc=new Chunk("DEPARTMENT:"+deptv);
		for(int i=0; i<4; i++){
			Chunk tab = new Chunk("     ");
	        dept.add(tab);
	      }
		dept.add(depc);
		document.add(new Paragraph(" "));
		document.add(dept);
		
	    Vector v = new Vector(facultydata.keySet());
	    Collections.sort(v);
	    
	    // Display (sorted) hashtable.
	    
		
		Enumeration flist=v.elements();
		
		while(flist.hasMoreElements())
		{
		String fid=flist.nextElement().toString();
		String fname=new FacultyDB().getFacultyName(fid);
			Vector subjects=(Vector)facultydata.get(fid);
			PdfPTable table = new PdfPTable(4);
			PdfPCell cell = new PdfPCell(new Phrase(fname));
			cell.setColspan(4);
			cell.setHorizontalAlignment(0); //0=Left, 1=Centre, 2=Right
			
			table.addCell(cell);
			table.addCell("Subject Name");
			table.addCell("Class");
			table.addCell("Feedback Result");
			table.addCell("No.of Students");
			
		for(int i=0;i<subjects.size();i++)
		{
			Vector subject=(Vector)subjects.get(i);
			String subjname=subject.get(0).toString();
			String cls=subject.get(1).toString();
			int res=((Integer)subject.get(2)).intValue();
			int totst=((Integer)subject.get(3)).intValue();
			
		
		table.addCell(subjname);
		table.addCell(cls);
		table.addCell(new Integer(res).toString());
		table.addCell(new Integer(totst).toString());
		
		}
		try {
			document.add(new Paragraph(" "));
			document.add(new Paragraph(" "));
			document.add(table);
	
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
	}
}
}