

import java.io.IOException;
import java.sql.Connection;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

import dao.DBConnection;
import dao.FeedBackDB;

/**
 * Servlet implementation class FeedbackStatus
 */
public class FeedbackStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String branch=null,year=null,sem=null,sec=null;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FeedbackStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		processStatus(request,response);
		response.sendRedirect("./feedbackstatus.jsp");
        /*try
        {
		Connection con=con=new DBConnection().getDatabaseConnection();
		(Here the parameter file should be in .jasper extension
	i.e., the compiled report)

		JasperExportManager.exportReportToPdfFile(print, "report1.pdf");
		HashMap params=new HashMap();
		branch=getDeptName(branch);
		params.put("branch",branch);
		params.put("year",year);
		params.put("sem",sem);
		params.put("sec",sec);

		//JasperPrint print = JasperFillManager.fillReport(fileName, hm, new JREmptyDataSource());

		JasperReport jReport=JasperCompileManager.compileReport("e:\\reports\\streport.jrxml");	    
		JasperPrint print = JasperFillManager.fillReport(jReport, params,con);
		// Create a PDF exporter
		JRExporter exporter = new JRPdfExporter();
		// JRExporter exporter = new JRHtmlExporter();
		//JRExporter exporter = new JRXlsExporter();
		// Configure the exporter (set output file name and print object)
		String outFileName = "e:/reports/feedbackstatus.pdf";
		exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, outFileName);
		exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);

		// Export the PDF file
		exporter.exportReport();


		Document document=new Document();

		response.setContentType("application/pdf");
		PdfWriter writer=PdfWriter.getInstance(document,response.getOutputStream());

		document.open();

		PdfReader reader = new PdfReader("e:/reports/feedbackstatus.pdf");
		int n = reader.getNumberOfPages();
		PdfImportedPage page;
		// Go through all pages
		for (int i = 1; i <= n; i++) {
			// Only page number 2 will be included

			page = writer.getImportedPage(reader, i);
			Image instance = Image.getInstance(page);
			document.add(instance);

		}
		document.close();
	}

	catch(JRException jre)
	{
		jre.printStackTrace();

	} catch (DocumentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/

}

/**
 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
 */

public void processStatus(HttpServletRequest request,HttpServletResponse response) throws IOException
{
	branch=request.getParameter("branch");
	year=request.getParameter("year");
	sem=request.getParameter("sem");
	sec=request.getParameter("sec");
	HttpSession session =request.getSession(true);
	session.setAttribute("branch", branch);
	session.setAttribute("year", year);
	session.setAttribute("sem", sem);
	session.setAttribute("sec", sec);
	
	FeedBackDB fdb=new FeedBackDB();
	fdb.loadAttemptedList(branch,year,sem,sec);
	fdb.loadNotAttemptedList(branch,year,sem,sec);
	


}
public String getDeptName(String dept)
{
	if(dept.equals("I.T"))
		return "IT";
	else if(dept.equals("C.S.E"))
		return "CSE";
	else if(dept.equals("E.C.E"))
		return "ECE";
	else if(dept.equals("E.E.E"))
		return "EEE";
	else if(dept.equals("MECH"))
		return "MECH";
	else if(dept.equals("CIVIL"))
		return "Civil";
	else if(dept.equals("M.C.A"))
		return "MCA";
	else if(dept.equals("M.B.A"))
		return "MBA";
	return "";
}


}
