

import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

import dao.ClassReportDB;
import dao.DBConnection;
import dao.FBSFetchDataBean;
import dao.FBSMiscUtilitiesBean;
import dao.FacultyReportDB;

/**
 * Servlet implementation class ReportViewer
 */
public class ClassFeedbackReport extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClassFeedbackReport() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	    try
	    {
	    	FBSMiscUtilitiesBean miscUtil=new FBSMiscUtilitiesBean();
	    	 String branch=miscUtil.noNull(request.getParameter("branch"));
	    	 String year=miscUtil.noNull(request.getParameter("year"));
	    	 String sem=miscUtil.noNull(request.getParameter("sem"));
	    	String sec=miscUtil.noNull(request.getParameter("sec"));
	    	HttpSession session=request.getSession(true);  
	    	String type=session.getAttribute("report").toString();
	    	//String fname=new FBSFetchDataBean().getFacultyName(request.getParameter("faculty"));
	    	
	    	ClassReportDB report=new ClassReportDB();
	        report.loadData(branch,year,sem,sec,type);
		    con=new DBConnection().getDatabaseConnection();
		    if(type.equals("aggregate"))
		    	response.sendRedirect("./displayreport.jsp");
		    		    
		    ReportGeneration rg=new ReportGeneration();
	        
	        
	        rg.createPDF(con,"general");
	        


	        Document document = new Document( PageSize.A4,30,36,25,36 );

	response.setContentType("application/pdf");
	PdfWriter writer=PdfWriter.getInstance(document,response.getOutputStream());

	document.open();

	PdfReader reader = new PdfReader("f:/reports/facultyPDF.pdf");
	int n = reader.getNumberOfPages();
	PdfImportedPage page;
	// Go through all pages
	for (int i = 1; i <= n; i++) {
		// Only page number 2 will be included
		
			page = writer.getImportedPage(reader, i);
			Image instance = Image.getInstance(page);
			document.add(instance);
		
	}
	document.close();
	    }

	    catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    new DBConnection().releaseDatabaseConnection(con);
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req,resp);
	}
	public String getDeptName(String dept)
	{
	   if(dept.equals("I.T"))
		   return "Information Technology(IT)";
		   else if(dept.equals("C.S.E"))
			   return "Computer Science(CSE)";
		   else if(dept.equals("E.C.E"))
			   return "Electronics and Communications(ECE)";
		   else if(dept.equals("E.E.E"))
			   return "Electrical and Electronics(EEE)";
		   else if(dept.equals("MECH"))
			   return "Mechanical";
		   else if(dept.equals("CIVIL"))
			   return "Civil";
		   else if(dept.equals("M.C.A"))
			   return "MCA";
		   else if(dept.equals("M.B.A"))
			   return "MBA";
	   return "";
	    }

}
