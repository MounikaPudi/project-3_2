

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Image;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

import dao.DBConnection;

/**
 * Servlet implementation class ReportViewer
 */
public class ReportViewer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReportViewer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	    try
	    {

	    Connection con=new DBConnection().getDatabaseConnection();
	    /*(Here the parameter file should be in .jasper extension
	i.e., the compiled report)*/

	//JasperExportManager.exportReportToPdfFile(print, "report1.pdf");


	//JasperPrint print = JasperFillManager.fillReport(fileName, hm, new JREmptyDataSource());

	JasperPrint print = JasperFillManager.fillReport("e:\\reports\\faculty1.jasper", null, new JREmptyDataSource());
	// Create a PDF exporter
	JRExporter exporter = new JRPdfExporter();
	// JRExporter exporter = new JRHtmlExporter();
	//JRExporter exporter = new JRXlsExporter();
	// Configure the exporter (set output file name and print object)
	String outFileName = "e:/reports/faculty1.pdf";
	exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, outFileName);
	exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);

	// Export the PDF file
	exporter.exportReport();
	
	Document document=new Document();

	response.setContentType("application/pdf");
	PdfWriter writer=PdfWriter.getInstance(document,response.getOutputStream());

	document.open();

	PdfReader reader = new PdfReader("e:/reports/faculty1.pdf");
	int n = reader.getNumberOfPages();
	PdfImportedPage page;
	// Go through all pages
	for (int i = 1; i <= n; i++) {
		// Only page number 2 will be included
		
			page = writer.getImportedPage(reader, i);
			Image instance = Image.getInstance(page);
			document.add(instance);
		
	}
	document.close();
	    }

	    catch(JRException jre)
	    {
	    	jre.printStackTrace();

	    } catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(req,resp);
	}
	

}
