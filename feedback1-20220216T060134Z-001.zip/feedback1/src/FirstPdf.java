import java.io.FileOutputStream;
import java.util.Date;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.lowagie.text.Anchor;
import com.lowagie.text.BadElementException;
import com.lowagie.text.Chapter;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.List;
import com.lowagie.text.ListItem;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Section;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.VerticalPositionMark;


public class FirstPdf {
	private static String FILE = "e:/FirstPdf.pdf";
	//private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18,Font.BOLD);
	//private static Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,	Font.NORMAL, BaseColor.RED);
	//private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 16,		Font.BOLD);
	//private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12,	Font.BOLD);

	public static void main(String[] args) {
		try {
			Document document = new Document();
			PdfWriter.getInstance(document, new FileOutputStream(FILE));
			document.open();
			addTitlePage(document);
		//	addContent(document);
			document.close();
			System.out.println("Document is created");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// iText allows to add metadata to the PDF which can be viewed in your Adobe
	// Reader
	// under File -> Properties
		private static void addTitlePage(Document document)
			throws DocumentException {
		Paragraph preface = new Paragraph();
		// We add one empty line
		addEmptyLine(preface, 1);
		// Lets write a big header
		Font font = new Font(Font.TIMES_ROMAN);
		font.setStyle(Font.BOLD);
		font.setSize(18);
		
		//preface.setFont(font);
//		preface.setAlignment(Element.ALIGN_CENTER);
		Paragraph title=new Paragraph("SHRI VISHNU ENGINEERING COLLEGE FOR WOMEN::BHIMAVARAM");
		Paragraph subtitle=new Paragraph("FEEDBACK ON FACULTY BY STUDENTS");
		title.setFont(font);
		subtitle.setFont(font);
		title.setAlignment(Element.ALIGN_CENTER);
		subtitle.setAlignment(Element.ALIGN_CENTER);
		document.add(title);
		document.add(subtitle);
		Chunk ay=new Chunk("ACADEMIC YEAR:2011-2012");
		Chunk dt=new Chunk("DATE:02/02/2012");
		Paragraph aydt=new Paragraph();
		for(int i=0; i<4; i++){
			Chunk tab = new Chunk("     ");
	        aydt.add(tab);
	      }
		aydt.add(ay);
		for(int i=0; i<8; i++){
			Chunk tab = new Chunk("     ");
	        aydt.add(tab);
	      }
		aydt.add(dt);
		document.add(new Paragraph(" "));
		document.add(aydt);
		
		
		Paragraph dept=new Paragraph();
		Chunk depc=new Chunk("DEPARTMENT:I.T");
		for(int i=0; i<4; i++){
			Chunk tab = new Chunk("     ");
	        dept.add(tab);
	      }
		dept.add(depc);
		document.add(new Paragraph(" "));
		document.add(dept);
		PdfPTable table = new PdfPTable(3);
		PdfPCell cell = new PdfPCell(new Phrase("Header spanning 3 columns"));
		cell.setColspan(3);
		cell.setHorizontalAlignment(0); //0=Left, 1=Centre, 2=Right
		
		table.addCell(cell);
		table.addCell("Col 1 Row 1");
		table.addCell("Col 2 Row 1");
		table.addCell("Col 3 Row 1");
		table.addCell("Col 1 Row 2");
		table.addCell("Col 2 Row 2");
		table.addCell("Col 3 Row 2");
		
		try {
			document.add(new Paragraph(" "));
			document.add(new Paragraph(" "));
			document.add(table);
	
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
	}

	private static void addContent(Document document) throws DocumentException {
		Anchor anchor = new Anchor("First Chapter");
		anchor.setName("First Chapter");

		// Second parameter is the number of the chapter
		Chapter catPart = new Chapter(new Paragraph(anchor), 1);

		Paragraph subPara = new Paragraph("Subcategory 1");
		Section subCatPart = catPart.addSection(subPara);
		subCatPart.add(new Paragraph("Hello"));

		subPara = new Paragraph("Subcategory 2");
		subCatPart = catPart.addSection(subPara);
		subCatPart.add(new Paragraph("Paragraph 1"));
		subCatPart.add(new Paragraph("Paragraph 2"));
		subCatPart.add(new Paragraph("Paragraph 3"));

		// Add a list
		createList(subCatPart);
		Paragraph paragraph = new Paragraph();
		addEmptyLine(paragraph, 5);
		subCatPart.add(paragraph);

		// Add a table
		createTable(subCatPart);

		// Now add all this to the document
		document.add(catPart);

		// Next section
		anchor = new Anchor("Second Chapter");
		anchor.setName("Second Chapter");

		// Second parameter is the number of the chapter
		catPart = new Chapter(new Paragraph(anchor), 1);

		subPara = new Paragraph("Subcategory");
		subCatPart = catPart.addSection(subPara);
		subCatPart.add(new Paragraph("This is a very important message"));

		// Now add all this to the document
		document.add(catPart);

	}

	private static void createTable(Section subCatPart)
			throws BadElementException {
		PdfPTable table = new PdfPTable(3);

		// t.setBorderColor(BaseColor.GRAY);
		// t.setPadding(4);
		// t.setSpacing(4);
		// t.setBorderWidth(1);

		PdfPCell c1 = new PdfPCell(new Phrase("Table Header 1"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Table Header 2"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);

		c1 = new PdfPCell(new Phrase("Table Header 3"));
		c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		table.addCell(c1);
		table.setHeaderRows(1);

		table.addCell("1.0");
		table.addCell("1.1");
		table.addCell("1.2");
		table.addCell("2.1");
		table.addCell("2.2");
		table.addCell("2.3");

		subCatPart.add(table);

	}

	private static void createList(Section subCatPart) {
		List list = new List(true, false, 10);
		list.add(new ListItem("First point"));
		list.add(new ListItem("Second point"));
		list.add(new ListItem("Third point"));
		subCatPart.add(list);
	}

	private static void addEmptyLine(Paragraph paragraph, int number) {
		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}
}

